"""Eval for the deterministic canary fault-detection mechanism (bin/canary_fault_detect.py).

This IS the eval the LLM /canary-fault-diagnosis skill never had: fixtures map a
canary state + a fixed clock to the expected fault class and regeneration safety,
pin the precedence (a broken gate outranks staleness), and assert idempotency.
The clock is injected so the eval never depends on wall-time.
"""
from __future__ import annotations

import contextlib
import io
import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from bin.canary_fault_detect import classify, main  # type: ignore[import-not-found]
from bin import canary_fault_detect


# Fixed reference clock for every fixture — deterministic, no wall-time.
NOW = datetime(2026, 6, 16, 12, 0, 0, tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
# Factories
# ---------------------------------------------------------------------------

def _canary(days_ago: float = 1.0, gate_working: bool = True,
            max_age_days: int = 7) -> dict:
    """Build a canary whose last_run is `days_ago` before the reference clock."""
    last_run = (NOW - timedelta(days=days_ago)).isoformat()
    return {"last_run": last_run, "gate_working": gate_working, "max_age_days": max_age_days}


# ---------------------------------------------------------------------------
# Fault classes
# ---------------------------------------------------------------------------

class FaultClassTests(unittest.TestCase):

    def test_classifies_missing_file_as_missing(self) -> None:
        verdict = classify(None, NOW)
        self.assertEqual(verdict["fault_class"], "missing")

    def test_classifies_gate_working_false_as_gate_not_working(self) -> None:
        verdict = classify(_canary(gate_working=False), NOW)
        self.assertEqual(verdict["fault_class"], "gate-not-working")

    def test_classifies_absent_timestamp_as_corrupt(self) -> None:
        verdict = classify({"gate_working": True}, NOW)
        self.assertEqual(verdict["fault_class"], "corrupt")

    def test_classifies_unparseable_timestamp_as_corrupt(self) -> None:
        verdict = classify({"gate_working": True, "last_run": "not-a-date"}, NOW)
        self.assertEqual(verdict["fault_class"], "corrupt")

    def test_classifies_old_run_as_stale(self) -> None:
        verdict = classify(_canary(days_ago=10, max_age_days=7), NOW)
        self.assertEqual(verdict["fault_class"], "stale")

    def test_classifies_recent_run_as_healthy(self) -> None:
        verdict = classify(_canary(days_ago=1, max_age_days=7), NOW)
        self.assertEqual(verdict["fault_class"], "healthy")


# ---------------------------------------------------------------------------
# Precedence — a broken gate outranks staleness
# ---------------------------------------------------------------------------

class PrecedenceTests(unittest.TestCase):

    def test_broken_gate_outranks_stale_timestamp(self) -> None:
        # Both broken AND stale: must report gate-not-working (forbids regeneration).
        verdict = classify(_canary(days_ago=99, gate_working=False, max_age_days=7), NOW)
        self.assertEqual(verdict["fault_class"], "gate-not-working")


# ---------------------------------------------------------------------------
# Staleness boundary + custom window
# ---------------------------------------------------------------------------

class StalenessBoundaryTests(unittest.TestCase):

    def test_run_exactly_at_max_age_is_healthy(self) -> None:
        # age == max_age is not yet stale (reducer uses strictly-greater).
        verdict = classify(_canary(days_ago=7, max_age_days=7), NOW)
        self.assertEqual(verdict["fault_class"], "healthy")

    def test_run_one_day_past_max_age_is_stale(self) -> None:
        verdict = classify(_canary(days_ago=8, max_age_days=7), NOW)
        self.assertEqual(verdict["fault_class"], "stale")

    def test_respects_custom_max_age_window(self) -> None:
        # 20 days old but a 35-day window -> still healthy.
        verdict = classify(_canary(days_ago=20, max_age_days=35), NOW)
        self.assertEqual(verdict["fault_class"], "healthy")

    def test_explicit_null_max_age_falls_back_to_default(self) -> None:
        # A canary file with "max_age_days": null must classify via the default
        # window, not raise TypeError on `age > None`.
        canary = _canary(days_ago=1)
        canary["max_age_days"] = None
        verdict = classify(canary, NOW, default_max_age_days=7)
        self.assertEqual(verdict["fault_class"], "healthy")

    def test_explicit_null_max_age_still_detects_stale(self) -> None:
        canary = _canary(days_ago=8)
        canary["max_age_days"] = None
        verdict = classify(canary, NOW, default_max_age_days=7)
        self.assertEqual(verdict["fault_class"], "stale")

    def test_zero_max_age_is_preserved_not_defaulted(self) -> None:
        # A configured 0 means must-run-daily: a 3-day-old run is stale. An `or`
        # fallback would silently widen this to the 7-day default (fail-open).
        verdict = classify(_canary(days_ago=3, max_age_days=0), NOW, default_max_age_days=7)
        self.assertEqual(verdict["fault_class"], "stale")


# ---------------------------------------------------------------------------
# Regeneration safety
# ---------------------------------------------------------------------------

class RegenerationSafetyTests(unittest.TestCase):

    def test_stale_canary_is_safe_to_regenerate(self) -> None:
        self.assertTrue(classify(_canary(days_ago=10), NOW)["safe_to_regenerate"])

    def test_missing_canary_is_safe_to_regenerate(self) -> None:
        self.assertTrue(classify(None, NOW)["safe_to_regenerate"])

    def test_broken_gate_is_not_safe_to_regenerate(self) -> None:
        self.assertFalse(classify(_canary(gate_working=False), NOW)["safe_to_regenerate"])

    def test_healthy_canary_is_not_flagged_for_regeneration(self) -> None:
        self.assertFalse(classify(_canary(days_ago=1), NOW)["safe_to_regenerate"])


# ---------------------------------------------------------------------------
# Metric parity + naive-timestamp handling
# ---------------------------------------------------------------------------

class VerdictShapeTests(unittest.TestCase):

    def test_fault_value_is_one_for_fault(self) -> None:
        self.assertEqual(classify(None, NOW)["fault_value"], 1.0)

    def test_fault_value_is_zero_for_healthy(self) -> None:
        self.assertEqual(classify(_canary(days_ago=1), NOW)["fault_value"], 0.0)

    def test_reports_age_in_days(self) -> None:
        self.assertEqual(classify(_canary(days_ago=10), NOW)["age_days"], 10)

    def test_naive_timestamp_treated_as_utc(self) -> None:
        naive = (NOW - timedelta(days=2)).replace(tzinfo=None).isoformat()
        verdict = classify({"gate_working": True, "last_run": naive, "max_age_days": 7}, NOW)
        self.assertEqual(verdict["age_days"], 2)


# ---------------------------------------------------------------------------
# Wrong-shape canary file (valid JSON that is not an object)
# ---------------------------------------------------------------------------

class NonDictCanaryFileTests(unittest.TestCase):
    """A canary file holding valid JSON of the wrong shape (list/string/number)
    is a corrupt write: it must land on the same corrupt fallback as unparseable
    bytes, not crash with an uncaught AttributeError before the verdict."""

    def _verdict_for(self, payload: str) -> tuple[int, dict]:
        with tempfile.TemporaryDirectory() as td:
            canary = Path(td) / "security_gate_canary.json"
            canary.write_text(payload, encoding="utf-8")
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                exit_code = main(["--canary", str(canary), "--json"])
        return exit_code, json.loads(out.getvalue())

    def test_json_list_canary_is_graded_corrupt(self) -> None:
        exit_code, report = self._verdict_for("[]")
        self.assertEqual(report["fault_class"], "corrupt")
        self.assertEqual(exit_code, 1)

    def test_json_string_canary_is_graded_corrupt(self) -> None:
        exit_code, report = self._verdict_for('"gate ok"')
        self.assertEqual(report["fault_class"], "corrupt")
        self.assertEqual(exit_code, 1)


# ---------------------------------------------------------------------------
# Unreadable canary path — exists() is True but reading it raises OSError
# ---------------------------------------------------------------------------

class UnreadableCanaryFileTests(unittest.TestCase):
    """A canary path that exists but can't be read as text (permission-denied
    file, or a directory where a file was expected) must not crash main() with
    an uncaught OSError -- it should degrade to the same 'corrupt write'
    handling as unparseable JSON, per the module's own read-only contract."""

    def test_directory_at_canary_path_is_graded_corrupt_not_a_crash(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            # exists() is True for a directory, but read_text() raises
            # IsADirectoryError (an OSError subclass) -- deterministic across
            # platforms and independent of file permissions/root privileges.
            canary_dir = Path(td) / "security_gate_canary.json"
            canary_dir.mkdir()
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                exit_code = main(["--canary", str(canary_dir), "--json"])
        report = json.loads(out.getvalue())
        self.assertEqual(report["fault_class"], "corrupt")
        self.assertEqual(exit_code, 1)

    def test_load_state_propagates_os_error_for_unreadable_path(self) -> None:
        # Direct unit check on the loader itself: reading a directory as text
        # raises OSError, not ValueError -- the caller's except clause must
        # catch both, not just ValueError.
        with tempfile.TemporaryDirectory() as td:
            canary_dir = Path(td) / "security_gate_canary.json"
            canary_dir.mkdir()
            with self.assertRaises(OSError):
                canary_fault_detect._load_state(canary_dir)


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------

class IdempotencyTests(unittest.TestCase):

    def test_same_state_yields_identical_verdict(self) -> None:
        state = _canary(days_ago=10, max_age_days=7)
        self.assertEqual(classify(state, NOW), classify(state, NOW))



# ---------------------------------------------------------------------------
# Malformed state shape — the parsed JSON is valid JSON but not an object
# ---------------------------------------------------------------------------

class MalformedStateShapeTests(unittest.TestCase):

    def test_list_state_classified_as_corrupt_not_a_crash(self) -> None:
        verdict = classify([], NOW)
        self.assertEqual(verdict["fault_class"], "corrupt")

    def test_string_state_classified_as_corrupt_not_a_crash(self) -> None:
        verdict = classify("not-an-object", NOW)
        self.assertEqual(verdict["fault_class"], "corrupt")

    def test_list_state_reports_no_age(self) -> None:
        verdict = classify([1, 2, 3], NOW)
        self.assertIsNone(verdict["age_days"])


if __name__ == "__main__":
    unittest.main()
