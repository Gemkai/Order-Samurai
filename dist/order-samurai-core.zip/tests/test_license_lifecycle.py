"""Paid lifecycle tests for the Order Samurai Pro entitlement (agentica_core/licensing.py).

Mocks the provider boundary (execution/gumroad_mcp.py, execution/lemonsqueezy_mcp.py) --
no test in this file makes a real network call. Covers activation, the fail-closed
matrix for every non-valid key shape, offline re-verification, the Free-tier gate in
bin/lib_pro_gate.sh, uninstall's license-preservation behavior, and the key-masking
contract so a raw license key never reaches stdout/stderr/logs.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _layout import governance_root  # noqa: E402

ROOT = governance_root(__file__)
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import agentica_core.licensing as licensing  # noqa: E402
import execution.gumroad_mcp as gumroad_mcp  # noqa: E402
import execution.lemonsqueezy_mcp as lemonsqueezy_mcp  # noqa: E402

LIB_PRO_GATE = ROOT / "bin" / "lib_pro_gate.sh"
SAMURAI_BIN = ROOT / "bin" / "samurai"

FAKE_KEY = "SAMURAI-PRO-KEY-2026-7781-9921-X"


# --------------------------------------------------------------------------- #
# Provider mocking helpers
# --------------------------------------------------------------------------- #

def _patch_providers(
    monkeypatch,
    *,
    gumroad_validate=None,
    gumroad_activate=None,
    lemonsqueezy_validate=None,
    lemonsqueezy_activate=None,
):
    """Patch the SAME module objects licensing.activate() lazily imports from.

    licensing.activate() does `from execution.gumroad_mcp import validate_license_key
    as g_val` *inside the function body* on every call, so patching the attribute on
    the already-imported module object is picked up on the next call.
    """
    if gumroad_validate is not None:
        monkeypatch.setattr(gumroad_mcp, "validate_license_key", gumroad_validate)
    if gumroad_activate is not None:
        monkeypatch.setattr(gumroad_mcp, "activate_license_key", gumroad_activate)
    if lemonsqueezy_validate is not None:
        monkeypatch.setattr(lemonsqueezy_mcp, "validate_license_key", lemonsqueezy_validate)
    if lemonsqueezy_activate is not None:
        monkeypatch.setattr(lemonsqueezy_mcp, "activate_license_key", lemonsqueezy_activate)


def _never_called(*_args, **_kwargs):
    raise AssertionError("provider function was called when it should not have been")


class _CallCounter:
    """Wraps a return value so tests can assert a provider fn's call count."""

    def __init__(self, result):
        self.result = result
        self.calls = 0

    def __call__(self, *_args, **_kwargs):
        self.calls += 1
        return self.result


# --------------------------------------------------------------------------- #
# 1. Valid key activates
# --------------------------------------------------------------------------- #

def test_valid_pro_key_activates_and_persists(tmp_path, monkeypatch):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))

    _patch_providers(
        monkeypatch,
        gumroad_validate=lambda key, product_id=None: {
            "valid": True,
            "license_key": key,
            "customer_email": "buyer@example.com",
            "status": "active",
            "refunded": False,
        },
        gumroad_activate=lambda key, instance_name: {
            "activated": True,
            "instance_id": "gum_abc123",
            "instance_name": instance_name,
            "license_key": key,
            "customer_email": "buyer@example.com",
        },
    )

    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is True

    lic_path = tmp_path / "license.json"
    assert lic_path.exists()
    mode = lic_path.stat().st_mode & 0o777
    assert mode == 0o600, f"license.json must be 0600, got {oct(mode)}"

    assert licensing.is_pro() is True


# --------------------------------------------------------------------------- #
# 2. Fail-closed matrix -- invalid / malformed / expired / revoked / refunded /
#    wrong-product keys must never yield Pro, and must never leave a file behind.
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize(
    "case,gumroad_val,lemonsqueezy_val",
    [
        (
            "invalid",
            {"valid": False, "error": "license key not recognized by Gumroad"},
            {"valid": False, "error": "license key not recognized by Lemon Squeezy"},
        ),
        (
            "expired",
            {"valid": False, "status": "expired", "error": "license key expired"},
            {"valid": False, "status": "expired", "error": "license key expired"},
        ),
        (
            "revoked",
            {"valid": False, "status": "revoked", "error": "license key revoked"},
            {"valid": False, "status": "revoked", "error": "license key revoked"},
        ),
        (
            "wrong_product",
            {"valid": False, "error": "license key belongs to a different product"},
            {"valid": False, "error": "license key belongs to a different product"},
        ),
    ],
)
def test_non_valid_keys_fail_closed(tmp_path, monkeypatch, case, gumroad_val, lemonsqueezy_val):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    _patch_providers(
        monkeypatch,
        gumroad_validate=lambda key, product_id=None, _v=gumroad_val: _v,
        gumroad_activate=_never_called,
        lemonsqueezy_validate=lambda key, instance_id=None, _v=lemonsqueezy_val: _v,
        lemonsqueezy_activate=_never_called,
    )

    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is False, f"{case} key must not activate"
    assert licensing.is_pro() is False, f"{case} key must not yield Pro"
    assert not (tmp_path / "license.json").exists(), f"{case} key must not leave a license file"


def test_refunded_key_fails_closed(tmp_path, monkeypatch):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    # Gumroad reports the key as VALID but refunded -- must still fail closed,
    # and must never even try Lemon Squeezy (gumroad already answered "valid").
    _patch_providers(
        monkeypatch,
        gumroad_validate=lambda key, product_id=None: {
            "valid": True,
            "status": "refunded",
            "refunded": True,
            "customer_email": "buyer@example.com",
        },
        gumroad_activate=_never_called,
        lemonsqueezy_validate=_never_called,
        lemonsqueezy_activate=_never_called,
    )

    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is False
    assert "refund" in result["message"].lower()
    assert licensing.is_pro() is False
    assert not (tmp_path / "license.json").exists()


def test_malformed_key_fails_closed_without_calling_provider(tmp_path, monkeypatch):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    _patch_providers(
        monkeypatch,
        gumroad_validate=_never_called,
        gumroad_activate=_never_called,
        lemonsqueezy_validate=_never_called,
        lemonsqueezy_activate=_never_called,
    )

    for malformed in ("", "   ", None):
        result = licensing.activate(malformed, instance_name="macbook-dev")
        assert result["ok"] is False
        assert "empty" in result["message"].lower()

    assert licensing.is_pro() is False
    assert not (tmp_path / "license.json").exists()


# --------------------------------------------------------------------------- #
# 3. Network error during activation fails closed with a retry message.
#    Regression: a SAMURAI-PRO-KEY prefix used to be treated as valid on a
#    network error. This must never happen for ANY key shape, prefix included.
# --------------------------------------------------------------------------- #

def test_network_error_during_activation_fails_closed_with_retry_message(tmp_path, monkeypatch):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))

    network_error = {
        "valid": False,
        "error": "Could not reach Lemon Squeezy to validate this license (timed out). "
                 "Check your network connection and try again.",
    }
    _patch_providers(
        monkeypatch,
        gumroad_validate=lambda key, product_id=None: network_error,
        gumroad_activate=_never_called,
        lemonsqueezy_validate=lambda key, instance_id=None: network_error,
        lemonsqueezy_activate=_never_called,
    )

    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is False
    assert "try again" in result["message"].lower()
    assert licensing.is_pro() is False
    assert not (tmp_path / "license.json").exists()


def test_gumroad_network_error_is_not_reported_as_invalid_key(tmp_path, monkeypatch):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    _patch_providers(
        monkeypatch,
        gumroad_validate=lambda key, product_id=None: {
            "valid": False,
            "error": "Could not reach Gumroad (timed out). Check your network connection and try again.",
        },
        gumroad_activate=_never_called,
        lemonsqueezy_validate=_never_called,
        lemonsqueezy_activate=_never_called,
    )

    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is False
    assert result["message"].startswith("network error")
    assert "invalid" not in result["message"].lower()
    assert not (tmp_path / "license.json").exists()


def test_unrecognized_key_reports_gumroad_reason_not_fallback_error(tmp_path, monkeypatch):
    # Lemon Squeezy answers an unknown key with HTTP 404, which its client words as
    # "Could not reach ...". A typo'd key must still read as invalid, not as a network fault.
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    _patch_providers(
        monkeypatch,
        gumroad_validate=lambda key, product_id=None: {
            "valid": False, "error": "license key not recognized by Gumroad",
        },
        gumroad_activate=_never_called,
        lemonsqueezy_validate=lambda key, instance_id=None: {
            "valid": False,
            "error": "Could not reach Lemon Squeezy to validate this license "
                     "(HTTP Error 404: Not Found). Check your network connection and try again.",
        },
        lemonsqueezy_activate=_never_called,
    )

    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is False
    assert result["message"] == "license key invalid: license key not recognized by Gumroad"


def test_gumroad_activation_increments_seat_count_exactly_once(tmp_path, monkeypatch):
    import urllib.parse
    import urllib.request

    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    increments = []

    def fake_urlopen(req, *_args, **_kwargs):
        sent = urllib.parse.parse_qs(req.data.decode("utf-8"))
        increments.append(sent.get("increment_uses_count", ["true"])[0])
        return _FakeResponse(json.dumps({"success": True, "purchase": {"email": "buyer@example.com"}}).encode())

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is True
    assert increments.count("true") == 1, f"each activation must burn one seat, got {increments}"


def test_gumroad_instance_id_is_deterministic_across_processes():
    code = (
        "import sys; sys.path.insert(0, sys.argv[1]);"
        "import execution.gumroad_mcp as g;"
        "g.validate_license_key = lambda *a, **k: {'valid': True};"
        "print(g.activate_license_key('KEY-1', 'host-a')['instance_id'])"
    )
    ids = {
        subprocess.run([sys.executable, "-c", code, str(ROOT)], capture_output=True, text=True,
                       check=True).stdout.strip()
        for _ in range(3)
    }
    assert len(ids) == 1, f"instance_id must be stable across runs, got {ids}"


def test_dashboard_summary_exposes_tier_only(tmp_path, monkeypatch):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    assert licensing.dashboard_summary() == {"tier": "free"}

    (tmp_path / "license.json").write_text(json.dumps({
        "tier": "pro", "valid": True, "status": "active",
        "license_key": FAKE_KEY, "customer_email": "buyer@example.com",
    }))
    assert licensing.dashboard_summary() == {"tier": "pro"}


# --------------------------------------------------------------------------- #
# 4. After activation, verification works OFFLINE -- no provider call on is_pro().
# --------------------------------------------------------------------------- #

def test_offline_verification_never_calls_provider(tmp_path, monkeypatch):
    # Changed: is_pro() now re-verifies during the refund window, so it only stays offline
    # within 24h of the last check, or forever once the entitlement is settled.
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))

    validate_counter = _CallCounter({
        "valid": True, "license_key": FAKE_KEY, "status": "active",
        "refunded": False, "customer_email": "buyer@example.com",
    })
    _patch_providers(
        monkeypatch,
        gumroad_validate=validate_counter,
        gumroad_activate=lambda key, instance_name: {
            "activated": True, "instance_id": "gum_abc123",
            "instance_name": instance_name, "license_key": key,
        },
    )

    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is True
    calls_after_activation = validate_counter.calls
    assert calls_after_activation >= 1

    # Now make ANY further provider call an assertion failure, and confirm
    # repeated is_pro()/status() calls never touch the network at all.
    _patch_providers(monkeypatch, gumroad_validate=_never_called, lemonsqueezy_validate=_never_called)

    # Within 24h of the activation-time check: no provider call.
    for _ in range(3):
        assert licensing.is_pro() is True
    assert licensing.status()["activated"] is True

    # A settled entitlement never calls the provider, however old the last check is.
    ent = json.loads((tmp_path / "license.json").read_text())
    ent.update(settled=True, last_checked_at="2020-01-01T00:00:00+00:00")
    (tmp_path / "license.json").write_text(json.dumps(ent))
    for _ in range(3):
        assert licensing.is_pro() is True
    assert licensing.status()["activated"] is True


# --------------------------------------------------------------------------- #
# 5. Free Core still functions without any license.
# --------------------------------------------------------------------------- #

def test_lib_pro_gate_is_pro_exits_1_on_free_tier(tmp_path):
    env = dict(os.environ)
    env["SAMURAI_HOME"] = str(tmp_path)  # no license.json written here
    res = subprocess.run(
        ["bash", "-c", f'source "{LIB_PRO_GATE}"; is_pro'],
        capture_output=True, text=True, env=env,
    )
    assert res.returncode == 1


def test_lib_pro_gate_require_pro_exits_2_with_upgrade_notice(tmp_path):
    env = dict(os.environ)
    env["SAMURAI_HOME"] = str(tmp_path)
    res = subprocess.run(
        ["bash", "-c", f'source "{LIB_PRO_GATE}"; require_pro "Nightly Dojo"'],
        capture_output=True, text=True, env=env,
    )
    assert res.returncode == 2
    assert "Pro feature" in res.stderr
    assert "samurai activate" in res.stderr


# --------------------------------------------------------------------------- #
# 6. License verification transmits no source code / prompts / telemetry --
#    only the key (+ instance identifiers) leave the machine.
# --------------------------------------------------------------------------- #

ALLOWED_PAYLOAD_KEYS = {"license_key", "product_id", "instance_id", "instance_name", "increment_uses_count"}


class _FakeResponse:
    def __init__(self, body: bytes):
        self._body = body

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def test_activation_payload_contains_only_key_and_instance_identifiers(monkeypatch):
    import urllib.parse
    import urllib.request

    captured = {}

    def fake_urlopen(req, *_args, **_kwargs):
        captured["data"] = urllib.parse.parse_qs(req.data.decode("utf-8"))
        return _FakeResponse(json.dumps({"success": True, "purchase": {"email": "buyer@example.com"}}).encode())

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    gumroad_mcp.validate_license_key(FAKE_KEY)
    sent_keys = set(captured["data"].keys())
    assert sent_keys <= ALLOWED_PAYLOAD_KEYS, f"unexpected fields sent to provider: {sent_keys - ALLOWED_PAYLOAD_KEYS}"

    captured.clear()

    def fake_urlopen_ls(req, *_args, **_kwargs):
        captured["data"] = urllib.parse.parse_qs(req.data.decode("utf-8"))
        return _FakeResponse(json.dumps({"activated": True, "instance": {"id": "ls_1"}}).encode())

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen_ls)
    lemonsqueezy_mcp.activate_license_key(FAKE_KEY, "macbook-dev")
    sent_keys = set(captured["data"].keys())
    assert sent_keys <= ALLOWED_PAYLOAD_KEYS, f"unexpected fields sent to provider: {sent_keys - ALLOWED_PAYLOAD_KEYS}"


# --------------------------------------------------------------------------- #
# 7. samurai uninstall preserves the license to
#    ~/order-samurai-license-backup.json (v1.0.1 behavior).
# --------------------------------------------------------------------------- #

def test_uninstall_preserves_license_backup(tmp_path):
    home_dir = tmp_path / "home"
    home_dir.mkdir()
    samurai_home = home_dir / ".samurai"
    samurai_home.mkdir()
    entitlement = {
        "tier": "pro", "valid": True, "status": "active",
        "license_key": FAKE_KEY, "instance_name": "macbook-dev",
    }
    (samurai_home / "license.json").write_text(json.dumps(entitlement))

    env = dict(os.environ)
    env["HOME"] = str(home_dir)
    env["SAMURAI_ROOT"] = str(ROOT)

    res = subprocess.run(
        [sys.executable, str(SAMURAI_BIN), "uninstall"],
        capture_output=True, text=True, env=env,
    )
    assert res.returncode == 0

    backup = home_dir / "order-samurai-license-backup.json"
    assert backup.exists()
    backed_up = json.loads(backup.read_text())
    assert backed_up["license_key"] == FAKE_KEY
    assert not samurai_home.exists()

    # Mask check lives here too: uninstall's own output must never echo the raw key.
    assert FAKE_KEY not in res.stdout
    assert FAKE_KEY not in res.stderr


# --------------------------------------------------------------------------- #
# 8. A license key value never appears in stdout/stderr of any command.
# --------------------------------------------------------------------------- #

def test_mask_key_never_reveals_full_license_key():
    masked = licensing._mask_key(FAKE_KEY)
    assert FAKE_KEY not in masked
    assert masked.endswith(FAKE_KEY[-4:])
    assert masked.startswith("****")


def test_status_masks_license_key_end_to_end(tmp_path, monkeypatch):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    entitlement = {
        "tier": "pro", "valid": True, "status": "active",
        "license_key": FAKE_KEY, "instance_name": "macbook-dev",
    }
    (tmp_path / "license.json").write_text(json.dumps(entitlement))

    st = licensing.status()
    assert FAKE_KEY not in json.dumps(st)
    assert st["license_key"].endswith(FAKE_KEY[-4:])


@pytest.mark.parametrize("email, shown", [
    ("buyer@example.com", "b***@example.com"),
    ("x@example.com", "x***@example.com"),
    ("not-an-email", "****"),
    ("@example.com", "****"),
    ("buyer@", "****"),
    ("a@b@example.com", "a***@example.com"),
    ("  buyer@example.com ", "b***@example.com"),
    (5, "****"),
    (["buyer@example.com"], "****"),
    (None, None),
])
def test_status_masks_customer_email(tmp_path, monkeypatch, email, shown):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    entitlement = {
        "tier": "pro", "valid": True, "status": "active",
        "license_key": FAKE_KEY, "customer_email": email,
    }
    (tmp_path / "license.json").write_text(json.dumps(entitlement))

    st = licensing.status()
    assert st["customer_email"] == shown
    if isinstance(email, str) and "@" in email:
        assert email.strip() not in json.dumps(st)


def test_samurai_license_cli_never_prints_full_email(tmp_path):
    entitlement = {
        "tier": "pro", "valid": True, "status": "active",
        "license_key": FAKE_KEY, "customer_email": "buyer@example.com",
    }
    (tmp_path / "license.json").write_text(json.dumps(entitlement))
    res = subprocess.run(
        [sys.executable, str(SAMURAI_BIN), "license"],
        capture_output=True, text=True, timeout=30,
        env={**os.environ, "SAMURAI_HOME": str(tmp_path)},
    )
    assert res.returncode == 0, res.stderr
    assert "buyer@example.com" not in res.stdout + res.stderr
    assert "b***@example.com" in res.stdout


def test_payload_schema_accepts_tier_only_license_block():
    import jsonschema
    from agentica_core import aggregate

    base = {"schema_version": "agentica.1", "timestamp": "2026-10-01T00:00:00Z", "reflexes": []}
    aggregate.validate_payload({**base, "license": {"tier": "pro"}})
    for leaky in ({"tier": "pro", "license_key": FAKE_KEY}, {"tier": "pro", "customer_email": "a@b.c"},
                  {"tier": "enterprise"}):
        with pytest.raises(jsonschema.ValidationError):
            aggregate.validate_payload({**base, "license": leaky})


# --------------------------------------------------------------------------- #
# 9. Real gumroad_mcp responses (fake HTTP): revoked purchases never activate,
#    provider faults read as network errors, and neither reaches Lemon Squeezy.
# --------------------------------------------------------------------------- #

def _gumroad_http(monkeypatch, *, purchase=None, http_error=None, exc=None):
    import io
    import urllib.error
    import urllib.request

    def fake_urlopen(req, *_args, **_kwargs):
        assert "gumroad.com" in req.full_url, f"key sent to a second provider: {req.full_url}"
        if exc is not None:
            raise exc
        if http_error is not None:
            raise urllib.error.HTTPError(req.full_url, http_error, "err", {}, io.BytesIO(b"{}"))
        return _FakeResponse(json.dumps({"success": True, "uses": 1, "purchase": {
            "email": "buyer@example.com", "refunded": False, "disputed": False,
            "chargebacked": False, **(purchase or {})}}).encode())

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)


@pytest.mark.parametrize("purchase", [
    {"refunded": True}, {"chargebacked": True}, {"disputed": True},
])
def test_revoked_gumroad_purchase_never_activates(tmp_path, monkeypatch, purchase):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    _gumroad_http(monkeypatch, purchase=purchase)
    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is False
    assert "refund" in result["message"].lower()
    assert licensing.is_pro() is False


def test_dispute_won_by_seller_still_activates(tmp_path, monkeypatch):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    _gumroad_http(monkeypatch, purchase={"disputed": True, "dispute_won": True})
    assert licensing.activate(FAKE_KEY, instance_name="macbook-dev")["ok"] is True
    assert licensing.is_pro() is True


@pytest.mark.parametrize("fault", ["http_503", "read_timeout"])
def test_gumroad_outage_reads_as_network_error(tmp_path, monkeypatch, fault):
    monkeypatch.setenv("SAMURAI_HOME", str(tmp_path))
    if fault == "http_503":
        _gumroad_http(monkeypatch, http_error=503)
    else:
        _gumroad_http(monkeypatch, exc=TimeoutError("The read operation timed out"))
    result = licensing.activate(FAKE_KEY, instance_name="macbook-dev")
    assert result["ok"] is False
    assert result["message"].startswith("network error"), result["message"]


# --------------------------------------------------------------------------- #
# 10. Pro entrypoints refuse to run on Free -- including when the gate lib is gone.
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("script", ["dojo_overnight.sh", "ronin-daemon.sh"])
@pytest.mark.parametrize("with_lib", [True, False])
def test_pro_entrypoints_exit_2_on_free(tmp_path, script, with_lib):
    import shutil

    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    shutil.copy2(ROOT / "bin" / script, bin_dir / script)
    if with_lib:
        shutil.copy2(LIB_PRO_GATE, bin_dir / "lib_pro_gate.sh")
    env = dict(os.environ, SAMURAI_HOME=str(tmp_path / "home"))
    res = subprocess.run(["bash", str(bin_dir / script)], capture_output=True, text=True,
                         env=env, timeout=30)
    assert res.returncode == 2, res.stderr


def test_ronin_arm_refuses_on_free_without_launching(tmp_path):
    env = dict(os.environ, SAMURAI_HOME=str(tmp_path))
    pid_file = ROOT / "state" / "daemon.pid"
    before = pid_file.read_text() if pid_file.exists() else None
    res = subprocess.run(["bash", str(ROOT / "bin" / "ronin"), "arm"], capture_output=True,
                         text=True, env=env, timeout=30)
    assert res.returncode == 2, res.stdout + res.stderr
    assert "Daemon armed" not in res.stdout
    assert (pid_file.read_text() if pid_file.exists() else None) == before
