"""Tests for metrics added recently with no dedicated coverage:
Gate_Canary_Fault, Local_Routing_Share, Avg_Session_Turns (graded),
Cache_Hit_Rate. (Canary_Failures retired 2026-07-11; Loop_Breaker_Fires
retired 2026-07-19 — dead emitter, metric-surface review Part E item 3.)
"""
import json
import sys
import types
from datetime import datetime, timedelta, timezone

import pytest

from agentica_core import aggregate as agg, scouts
from agentica_core.insights import _health


# ── helpers ──────────────────────────────────────────────────────────────────

def _sig(tmp_path, **files):
    """Write data files and return security_signals(tmp_path)."""
    d = tmp_path / "data"
    d.mkdir(exist_ok=True)
    for name, content in files.items():
        (d / name).write_text(json.dumps(content), encoding="utf-8")
    return scouts.security_signals(tmp_path)


# ── Local_Routing_Share ───────────────────────────────────────────────────────

class TestLocalRoutingShare:
    def test_mixed_tiers_returns_correct_percentage(self):
        recs = [
            {"model_tier": "LOCAL"},
            {"model_tier": "LOCAL"},
            {"model_tier": "FAST"},
            {"model_tier": "FREE"},
        ]
        assert agg.r_local_routing(recs) == 50.0

    def test_all_local_returns_100(self):
        recs = [{"model_tier": "LOCAL"}, {"model_tier": "local"}]
        assert agg.r_local_routing(recs) == 100.0

    def test_no_local_returns_0(self):
        recs = [{"model_tier": "FAST"}, {"model_tier": "FREE"}]
        assert agg.r_local_routing(recs) == 0.0

    def test_empty_records_returns_none(self):
        assert agg.r_local_routing([]) is None

    def test_records_without_model_tier_returns_none(self):
        assert agg.r_local_routing([{"status": "success"}]) is None

    def test_local_tier_case_insensitive(self):
        recs = [{"model_tier": "local"}, {"model_tier": "FAST"}]
        assert agg.r_local_routing(recs) == 50.0


# ── Avg_Session_Turns ─────────────────────────────────────────────────────────

class TestAvgSessionTurns:
    def test_turns_field_wins_over_row_counting(self):
        # Emitter-stamped turns are the real measurement; row counts are re-emits.
        recs = [
            {"session_id": "s1", "turns": 6}, {"session_id": "s1", "turns": 6},
            {"session_id": "s2", "turns": 2},
        ]
        # s1=6 turns (once, not per row), s2=2 → avg=4.0
        assert agg.r_avg_session_turns(recs) == 4.0

    def test_turns_is_cumulative_per_session_so_max_wins(self):
        # A resumed session re-emits the same sid with a higher cumulative count.
        recs = [{"session_id": "s1", "turns": 3}, {"session_id": "s1", "turns": 9}]
        assert agg.r_avg_session_turns(recs) == 9.0

    def test_zero_turns_means_not_parsed_and_is_not_graded(self):
        # turns=0 is "transcript unreadable", never a real zero-turn session.
        recs = [{"session_id": "s1", "turns": 0}, {"session_id": "s2", "turns": 5}]
        assert agg.r_avg_session_turns(recs) == 5.0

    def test_placeholder_sid_turns_count_individually(self):
        recs = [
            {"session_id": "local-session", "turns": 2},
            {"session_id": "local-session", "turns": 4},
        ]
        # placeholder sids never collapse into one session → avg of both
        assert agg.r_avg_session_turns(recs) == 3.0

    def test_two_sessions_without_turns_fall_back_to_row_proxy(self):
        recs = [
            {"session_id": "s1"}, {"session_id": "s1"}, {"session_id": "s1"},
            {"session_id": "s2"}, {"session_id": "s2"},
        ]
        # documented proxy: rows per session (claude re-emit count) — s1=3, s2=2 → 2.5
        assert agg.r_avg_session_turns(recs) == 2.5

    def test_single_session_without_turns_returns_row_count(self):
        recs = [{"session_id": "s1"}] * 4
        assert agg.r_avg_session_turns(recs) == 4.0

    def test_empty_records_returns_none(self):
        assert agg.r_avg_session_turns([]) is None

    def test_records_without_session_id_returns_none(self):
        assert agg.r_avg_session_turns([{"status": "success"}]) is None

    def test_graded_healthy_below_warn(self):
        rule = {"dir": "lower", "warn": 8, "fail": 15}
        # 5 turns → well below warn=8 → should score 100
        assert _health(5.0, rule) == 100.0

    def test_graded_at_fail_threshold(self):
        rule = {"dir": "lower", "warn": 8, "fail": 15}
        # 15 turns → at fail=15 → should score ~40
        score = _health(15.0, rule)
        assert score == pytest.approx(40.0, abs=1.0)

    def test_graded_between_warn_and_fail(self):
        rule = {"dir": "lower", "warn": 8, "fail": 15}
        score = _health(11.5, rule)  # midpoint
        assert 40.0 < score < 100.0


# Canary_Failures RETIRED 2026-07-11 — scout reader removed with the metric.


# ── Gate_Canary_Fault ─────────────────────────────────────────────────────────

class TestGateCanaryFault:
    def test_missing_file_absent_from_output(self, tmp_path):
        sig = scouts.security_signals(tmp_path)
        assert "gate_canary_fault" not in sig

    def test_working_fresh_canary_returns_0(self, tmp_path):
        now = datetime.now(timezone.utc).isoformat()
        sig = _sig(tmp_path, **{
            "security_gate_canary.json": {
                "gate_working": True,
                "last_run": now,
                "max_age_days": 7,
            }
        })
        assert sig["gate_canary_fault"] == 0

    def test_gate_not_working_returns_1(self, tmp_path):
        now = datetime.now(timezone.utc).isoformat()
        sig = _sig(tmp_path, **{
            "security_gate_canary.json": {
                "gate_working": False,
                "last_run": now,
                "max_age_days": 7,
            }
        })
        assert sig["gate_canary_fault"] == 1

    def test_stale_canary_returns_1(self, tmp_path):
        stale = (datetime.now(timezone.utc) - timedelta(days=10)).isoformat()
        sig = _sig(tmp_path, **{
            "security_gate_canary.json": {
                "gate_working": True,
                "last_run": stale,
                "max_age_days": 7,
            }
        })
        assert sig["gate_canary_fault"] == 1

    def test_fresh_within_budget_returns_0(self, tmp_path):
        recent = (datetime.now(timezone.utc) - timedelta(days=3)).isoformat()
        sig = _sig(tmp_path, **{
            "security_gate_canary.json": {
                "gate_working": True,
                "last_run": recent,
                "max_age_days": 7,
            }
        })
        assert sig["gate_canary_fault"] == 0

    def test_exactly_at_budget_boundary_passes(self, tmp_path):
        # days > max_age triggers fault; days == max_age does not
        exact = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
        sig = _sig(tmp_path, **{
            "security_gate_canary.json": {
                "gate_working": True,
                "last_run": exact,
                "max_age_days": 7,
            }
        })
        assert sig["gate_canary_fault"] == 0


# Loop_Breaker_Fires tests removed 2026-07-19 with the metric's retirement
# (dead emitter — see agentica_core/insights.py retirement comment).


# ── False-zero prevention (Task 2 bug fixes) ──────────────────────────────────

class TestReducerFalseZero:
    def test_total_cost_returns_none_when_field_absent(self):
        recs = [{"status": "success"}, {"status": "error"}]
        assert agg.r_total_cost(recs) is None

    def test_token_spend_returns_none_when_fields_absent(self):
        recs = [{"status": "success"}, {"status": "error"}]
        assert agg.r_token_spend(recs) is None

    def test_cost_per_task_returns_none_when_cost_absent(self):
        recs = [{"status": "success"}, {"status": "error"}]
        assert agg.r_cost_per_task(recs) is None

    def test_total_cost_returns_value_when_present(self):
        recs = [{"total_cost": 0.01}, {"total_cost": 0.02}]
        assert agg.r_total_cost(recs) == pytest.approx(0.03, abs=1e-6)

    def test_token_spend_returns_value_when_present(self):
        recs = [{"tokens_prompt": 100, "tokens_completion": 50}]
        assert agg.r_token_spend(recs) == 150


# ── Lesson_Graduation_Rate (AUTO-017) ─────────────────────────────────────────

def _queue_jsonl(tmp_path, skills):
    data_dir = tmp_path / ".claude" / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    path = data_dir / "skill_improve_queue.jsonl"
    path.write_text(
        "\n".join(json.dumps({"skill": s, "used_at": "2026-07-01T00:00:00Z",
                              "improve_after": "2026-07-02T00:00:00Z"}) for s in skills) + "\n",
        encoding="utf-8",
    )
    return path


def _eureka_md(tmp_path, rule_skills=(), body=""):
    data_dir = tmp_path / ".claude" / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    path = data_dir / "auto_eureka_skills.md"
    rule_lines = "\n".join(f"- **`/{s}`** → `bow/Some_Metric`\n  6/8 runs improved (75%)" for s in rule_skills)
    md = f"""# Auto Eureka

## GOTCHA — Skills That Rarely Resolve Their Target Metric

- something unrelated

## RULE — High-Effectiveness Skills

{rule_lines}

## CONTEXT — Mixed Effectiveness (30–70%)

{body}
"""
    path.write_text(md, encoding="utf-8")
    return path


class TestLessonGraduationRate:
    def test_missing_queue_file_returns_data_gap_not_fake_zero(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        result = agg._lesson_graduation_rate([])
        assert result["val"] is None
        assert result["data_gap"] is True
        assert result["calibrated"] is True

    def test_empty_queue_returns_data_gap(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _queue_jsonl(tmp_path, [])
        result = agg._lesson_graduation_rate([])
        assert result["val"] is None
        assert result["data_gap"] is True

    def test_missing_eureka_report_treats_all_as_ungraduated(self, tmp_path, monkeypatch):
        # Ledger has lessons, but the classification report hasn't run yet: 0%,
        # never a crash, never a fabricated non-zero.
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _queue_jsonl(tmp_path, ["simplify", "doctor"])
        result = agg._lesson_graduation_rate([])
        assert result["val"] == 0.0
        assert result["calibrated"] is True
        assert "data_gap" not in result

    def test_computes_real_percentage_from_both_sources(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _queue_jsonl(tmp_path, ["simplify", "audit-mechanisms", "doctor", "review"])
        _eureka_md(tmp_path, rule_skills=["simplify", "audit-mechanisms"])
        result = agg._lesson_graduation_rate([])
        # 2 of 4 queued skills graduated to RULE = 50%
        assert result["val"] == pytest.approx(50.0, abs=0.05)
        assert result["calibrated"] is True
        assert "data_gap" not in result

    def test_rule_skill_never_queued_does_not_count(self, tmp_path, monkeypatch):
        # A RULE-classified skill that was never in THIS ledger must not inflate
        # the rate — graduation is scoped to the ledger's own population.
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _queue_jsonl(tmp_path, ["doctor", "review"])
        _eureka_md(tmp_path, rule_skills=["simplify"])
        result = agg._lesson_graduation_rate([])
        assert result["val"] == 0.0

    def test_duplicate_queue_entries_dedupe_by_skill(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _queue_jsonl(tmp_path, ["simplify", "simplify", "simplify", "doctor"])
        _eureka_md(tmp_path, rule_skills=["simplify"])
        result = agg._lesson_graduation_rate([])
        # 1 of 2 unique queued skills graduated = 50%, not diluted by repeats
        assert result["val"] == pytest.approx(50.0, abs=0.05)

    def test_ignores_records_argument_entirely(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _queue_jsonl(tmp_path, ["simplify"])
        _eureka_md(tmp_path, rule_skills=["simplify"])
        fake_records = [{"total_cost": 999.0, "model_tier": "CLOUD"}] * 50
        result = agg._lesson_graduation_rate(fake_records)
        assert result["val"] == pytest.approx(100.0, abs=0.05)

    def test_registered_in_registry_under_bow_as_auto_percent(self):
        entry = next((e for e in agg.REGISTRY if e[2] == "Lesson_Graduation_Rate"), None)
        assert entry is not None, "Lesson_Graduation_Rate must be registered in aggregate.REGISTRY"
        pillar, group, key, reducer, tier, is_percent, is_count = entry
        assert pillar == "bow"
        assert tier == "AUTO"
        assert is_percent is True
        assert is_count is False
        assert reducer is agg._lesson_graduation_rate

    def test_build_pillars_reports_live_not_simulated(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _queue_jsonl(tmp_path, ["simplify", "doctor"])
        _eureka_md(tmp_path, rule_skills=["simplify"])
        pillars = agg.build_pillars([])
        env = pillars["bow"]["Agent Operation"]["Lesson_Graduation_Rate"]
        assert env["is_simulated"] is False
        assert env["tier"] == "AUTO"
        assert env["val"] != "—"


# ── Cache_Hit_Rate (AUTO-009) ─────────────────────────────────────────────────
# Contract correction: this reducer is pure over the records explicitly supplied by
# its caller. Native transcript sampling belongs to knowledge_metrics.collect.

def _write_transcript(projects_dir, name, lines):
    proj = projects_dir / "proj1"
    proj.mkdir(parents=True, exist_ok=True)
    path = proj / name
    path.write_text("\n".join(json.dumps(l) for l in lines) + "\n", encoding="utf-8")
    return path


def _usage_line(input_tokens=0, cache_creation=0, cache_read=0, output_tokens=0):
    return {
        "type": "assistant",
        "message": {"usage": {
            "input_tokens": input_tokens,
            "cache_creation_input_tokens": cache_creation,
            "cache_read_input_tokens": cache_read,
            "output_tokens": output_tokens,
        }},
    }


def _cache_record(platform, session, prompt=None, cached=0, *, known=True, creation=0):
    # Valid native summaries have an explicit all-events-known marker and all
    # provider input buckets, including a known zero cache-creation bucket.
    return {"platform": platform, "session_id": session,
            "tokens_prompt": prompt, "cache_read_tokens": cached,
            "cache_creation_tokens": creation, "usage_known": known}


class TestCacheHitRate:
    def test_missing_records_returns_data_gap_not_fake_zero(self, tmp_path, monkeypatch):
        # Ambient transcript content must not affect this pure reducer.
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _write_transcript(tmp_path / ".claude/projects", "s.jsonl",
                          [_usage_line(input_tokens=1, cache_read=999)])
        result = agg._cache_hit_rate([])
        assert result["val"] is None
        assert result["data_gap"] is True
        assert result["calibrated"] is True

    def test_is_token_weighted_across_distinct_platforms(self):
        result = agg._cache_hit_rate([
            _cache_record("claude", "a", 900, 90),
            _cache_record("codex", "b", 100, 100),
        ])
        assert result["val"] == pytest.approx(19.0)

    def test_deduplicates_cumulative_max_per_platform_session(self):
        result = agg._cache_hit_rate([
            _cache_record("claude", "same", 1000, 50),
            _cache_record("claude", "same", 1700, 200),
            _cache_record("codex", "same", 500, 250),
        ])
        assert result["val"] == pytest.approx(20.45, abs=0.01)

    def test_excludes_unknown_platforms_and_malformed_buckets(self):
        result = agg._cache_hit_rate([
            _cache_record("grok", "g", 10, 10),
            _cache_record("claude", "negative", -1, 0),
            _cache_record("claude", "bool", 100, True),
            _cache_record("codex", "valid", 400, 100),
        ])
        assert result["val"] == pytest.approx(25.0)

    def test_missing_cache_bucket_is_unknown_not_zero(self):
        result = agg._cache_hit_rate([
            _cache_record("claude", "missing", 100, None),
        ])
        assert result["val"] is None and result["data_gap"] is True

    def test_legacy_summary_without_known_marker_or_creation_bucket_is_a_gap(self):
        result = agg._cache_hit_rate([{
            "platform": "claude", "session_id": "legacy",
            "tokens_prompt": 100, "cache_read_tokens": 20,
        }])
        assert result["val"] is None and result["data_gap"] is True

    def test_registered_under_brush_as_auto_percent(self):
        entry = next((e for e in agg.REGISTRY if e[2] == "Cache_Hit_Rate"), None)
        assert entry is not None
        pillar, group, key, reducer, tier, is_percent, is_count = entry
        assert (pillar, group, key, tier, is_percent, is_count) == (
            "brush", "Token Efficiency", "Cache_Hit_Rate", "AUTO", True, False)
        assert reducer is agg._cache_hit_rate

    def test_build_pillars_consumes_pure_reducer_result(self):
        pillars = agg.build_pillars([_cache_record("claude", "s", 1000, 250)])
        env = pillars["brush"]["Token Efficiency"]["Cache_Hit_Rate"]
        assert env["val"] == "25.0"
        assert env["is_simulated"] is False and env["tier"] == "AUTO"


def _exec_line(reflex_id, ts, improved):
    return json.dumps({
        "timestamp": ts, "reflex_id": reflex_id, "improved": improved,
        "source": "reflex_engine", "status": "done",
    })


def _write_exec_log(root, *lines):
    d = root / "state"
    d.mkdir(parents=True, exist_ok=True)
    (d / "exec_log.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")


class TestMeanTimeToHeal:
    def setup_method(self):
        agg._MTTH_CACHE.update(t=0.0, v=None)

    def teardown_method(self):
        agg._MTTH_CACHE.update(t=0.0, v=None)

    def test_missing_exec_log_returns_data_gap_not_fake_zero(self, tmp_path, monkeypatch):
        monkeypatch.setattr(agg, "_ORDER_SAMURAI_ROOT", tmp_path)
        result = agg._mean_time_to_heal([])
        assert result["val"] is None
        assert result["data_gap"] is True
        assert result["calibrated"] is True

    def test_computes_span_first_fire_to_first_heal(self, tmp_path, monkeypatch):
        monkeypatch.setattr(agg, "_ORDER_SAMURAI_ROOT", tmp_path)
        _write_exec_log(tmp_path,
            _exec_line("metric:bow:X", "2026-06-08T00:00:00Z", False),
            _exec_line("metric:bow:X", "2026-06-08T00:02:00Z", True),   # heal at +120s
            _exec_line("metric:bow:X", "2026-06-08T00:05:00Z", True),   # later heal ignored
        )
        result = agg._mean_time_to_heal([])
        assert result["val"] == 120
        assert result["calibrated"] is True
        assert "data_gap" not in result

    def test_still_open_reflex_excluded_not_counted_as_zero(self, tmp_path, monkeypatch):
        monkeypatch.setattr(agg, "_ORDER_SAMURAI_ROOT", tmp_path)
        _write_exec_log(tmp_path,
            # healed reflex: 60s span
            _exec_line("metric:bow:A", "2026-06-08T00:00:00Z", False),
            _exec_line("metric:bow:A", "2026-06-08T00:01:00Z", True),
            # still-open reflex: never improved -> must be EXCLUDED, not averaged as 0
            _exec_line("metric:bow:B", "2026-06-08T00:00:00Z", False),
            _exec_line("metric:bow:B", "2026-06-08T09:00:00Z", False),
        )
        result = agg._mean_time_to_heal([])
        assert result["val"] == 60  # mean over the ONE healed reflex only

    def test_no_reflex_ever_healed_returns_data_gap(self, tmp_path, monkeypatch):
        monkeypatch.setattr(agg, "_ORDER_SAMURAI_ROOT", tmp_path)
        _write_exec_log(tmp_path,
            _exec_line("metric:bow:A", "2026-06-08T00:00:00Z", False),
            _exec_line("metric:bow:A", "2026-06-08T00:01:00Z", False),
        )
        result = agg._mean_time_to_heal([])
        assert result["val"] is None
        assert result["data_gap"] is True

    def test_heal_on_first_fire_is_zero_span_not_data_gap(self, tmp_path, monkeypatch):
        monkeypatch.setattr(agg, "_ORDER_SAMURAI_ROOT", tmp_path)
        _write_exec_log(tmp_path,
            _exec_line("metric:bow:A", "2026-06-08T00:00:00Z", True),
        )
        result = agg._mean_time_to_heal([])
        assert result["val"] == 0  # a genuine same-attempt heal, not a data gap
        assert "data_gap" not in result

    def test_ignores_records_argument_and_out_of_order_lines(self, tmp_path, monkeypatch):
        monkeypatch.setattr(agg, "_ORDER_SAMURAI_ROOT", tmp_path)
        _write_exec_log(tmp_path,
            _exec_line("metric:bow:A", "2026-06-08T00:03:00Z", True),   # heal, listed first
            _exec_line("metric:bow:A", "2026-06-08T00:00:00Z", False),  # earlier fire
        )
        fake_records = [{"reflex_id": "junk", "improved": True, "timestamp": "x"}] * 20
        result = agg._mean_time_to_heal(fake_records)
        assert result["val"] == 180  # start sorted to 00:00, heal at +180s

    def test_registered_in_registry_under_bow_autonomic_lower_is_better(self):
        entry = next((e for e in agg.REGISTRY if e[2] == "Mean_Time_To_Heal"), None)
        assert entry is not None, "Mean_Time_To_Heal must be registered in aggregate.REGISTRY"
        pillar, group, key, reducer, tier, higher_is_better, is_count = entry
        assert pillar == "bow"
        assert group == "Autonomic"
        assert tier == "AUTO"
        assert higher_is_better is False  # faster heal is better
        assert is_count is False
        assert reducer is agg._mean_time_to_heal

    def test_build_pillars_reports_live_not_simulated(self, tmp_path, monkeypatch):
        monkeypatch.setattr(agg, "_ORDER_SAMURAI_ROOT", tmp_path)
        _write_exec_log(tmp_path,
            _exec_line("metric:bow:A", "2026-06-08T00:00:00Z", False),
            _exec_line("metric:bow:A", "2026-06-08T00:01:00Z", True),
        )
        pillars = agg.build_pillars([])
        env = pillars["bow"]["Autonomic"]["Mean_Time_To_Heal"]
        assert env["is_simulated"] is False
        assert env["tier"] == "AUTO"
        assert env["val"] != "—"


def _install_fake_principle_audit(tmp_path, monkeypatch, rule_ids, violations, *, window=90):
    """Redirect _dead_rule_count's config-tier source to a controlled tmp fixture.

    Creates USERPROFILE/.claude/scripts (so the existence guard passes) and a
    principle_violations.jsonl, then injects a fake `principle_audit` module carrying
    the canonical PATTERNS / VIOLATIONS_FILE / RETIREMENT_WINDOW_DAYS the reducer reads.
    `violations` is a list of (rule_id, iso_ts) pairs (naive ISO, as principle_audit
    writes them)."""
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    (tmp_path / ".claude" / "scripts").mkdir(parents=True, exist_ok=True)
    data_dir = tmp_path / ".claude" / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    vfile = data_dir / "principle_violations.jsonl"
    vfile.write_text(
        "".join(json.dumps({"ts": ts, "rule_id": rid}) + "\n" for rid, ts in violations),
        encoding="utf-8",
    )
    fake = types.ModuleType("principle_audit")
    fake.PATTERNS = [{"rule_id": r} for r in rule_ids]
    fake.VIOLATIONS_FILE = vfile
    fake.RETIREMENT_WINDOW_DAYS = window
    monkeypatch.setitem(sys.modules, "principle_audit", fake)
    return vfile


def _iso(days_ago=0):
    return (datetime.now() - timedelta(days=days_ago)).isoformat(timespec="seconds")


class TestDeadRuleCount:
    """AUTO-014 Dead-Rule Detection: dead governance rules (0 hits in the 90d window),
    read from principle_audit.py's canonical PATTERNS + principle_violations.jsonl."""

    def setup_method(self):
        agg._DEAD_RULE_CACHE.update(t=0.0, v=None)

    def teardown_method(self):
        agg._DEAD_RULE_CACHE.update(t=0.0, v=None)

    def test_missing_scripts_dir_returns_data_gap_not_fake_zero(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))  # no .claude/scripts
        result = agg._dead_rule_count([])
        assert result["val"] is None
        assert result["data_gap"] is True
        assert result["calibrated"] is True

    def test_missing_violations_file_returns_data_gap(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        (tmp_path / ".claude" / "scripts").mkdir(parents=True)
        fake = types.ModuleType("principle_audit")
        fake.PATTERNS = [{"rule_id": "R1"}]
        fake.VIOLATIONS_FILE = tmp_path / ".claude" / "data" / "nope.jsonl"
        fake.RETIREMENT_WINDOW_DAYS = 90
        monkeypatch.setitem(sys.modules, "principle_audit", fake)
        result = agg._dead_rule_count([])
        assert result["val"] is None
        assert result["data_gap"] is True

    def test_counts_rules_with_no_recent_hits(self, tmp_path, monkeypatch):
        _install_fake_principle_audit(
            tmp_path, monkeypatch,
            rule_ids=["R1", "R2", "R3"],
            violations=[("R1", _iso(1))],  # only R1 fired recently
        )
        result = agg._dead_rule_count([])
        assert result["val"] == 2  # R2, R3 dead
        assert result["calibrated"] is True
        assert "data_gap" not in result
        assert "R2" in result["detail"] and "R3" in result["detail"]

    def test_hits_older_than_window_still_count_as_dead(self, tmp_path, monkeypatch):
        _install_fake_principle_audit(
            tmp_path, monkeypatch,
            rule_ids=["R1", "R2"],
            violations=[("R1", _iso(1)), ("R2", _iso(200))],  # R2 fired 200d ago
        )
        result = agg._dead_rule_count([])
        assert result["val"] == 1  # R2 outside 90d window -> dead
        assert "R2" in result["detail"]

    def test_all_rules_fired_returns_honest_zero_not_data_gap(self, tmp_path, monkeypatch):
        _install_fake_principle_audit(
            tmp_path, monkeypatch,
            rule_ids=["R1", "R2"],
            violations=[("R1", _iso(1)), ("R2", _iso(2))],
        )
        result = agg._dead_rule_count([])
        assert result["val"] == 0  # a real measured zero, honestly LIVE
        assert result["calibrated"] is True
        assert "data_gap" not in result

    def test_malformed_lines_are_skipped_like_cmd_retirement(self, tmp_path, monkeypatch):
        vfile = _install_fake_principle_audit(
            tmp_path, monkeypatch,
            rule_ids=["R1", "R2"],
            violations=[("R1", _iso(1))],
        )
        with open(vfile, "a", encoding="utf-8") as f:
            f.write("not json\n")
            f.write(json.dumps({"rule_id": "R2"}) + "\n")  # no ts -> KeyError -> skipped
        result = agg._dead_rule_count([])
        assert result["val"] == 1  # R2 (undated) not counted as fired -> stays dead

    def test_ignores_records_argument_entirely(self, tmp_path, monkeypatch):
        _install_fake_principle_audit(
            tmp_path, monkeypatch,
            rule_ids=["R1", "R2", "R3"],
            violations=[("R1", _iso(1))],
        )
        junk = [{"rule_id": "R2", "ts": _iso(1)}] * 50
        result = agg._dead_rule_count(junk)
        assert result["val"] == 2  # records must not influence the count

    def test_registered_in_registry_under_brush_code_health_as_count(self):
        entry = next((e for e in agg.REGISTRY if e[2] == "Dead_Rule_Count"), None)
        assert entry is not None, "Dead_Rule_Count must be registered in aggregate.REGISTRY"
        pillar, group, key, reducer, tier, higher_is_better, is_count = entry
        assert pillar == "brush"
        assert group == "Code Health"
        assert tier == "AUTO"
        assert higher_is_better is False  # fewer dead rules is better
        assert is_count is True
        assert reducer is agg._dead_rule_count

    def test_build_pillars_reports_live_not_simulated(self, tmp_path, monkeypatch):
        _install_fake_principle_audit(
            tmp_path, monkeypatch,
            rule_ids=["R1", "R2", "R3"],
            violations=[("R1", _iso(1))],
        )
        pillars = agg.build_pillars([])
        env = pillars["brush"]["Code Health"]["Dead_Rule_Count"]
        assert env["is_simulated"] is False
        assert env["tier"] == "AUTO"
        assert env["val"] == "2"
        assert env["is_count"] is True
# ── Compaction_Events (AUTO-010) ──────────────────────────────────────────────
# Like _cache_hit_rate, _compaction_events ignores the `records` arg entirely —
# compact_boundary is a structural transcript record, never a SessionEnd telemetry
# field. Tests point HOME/USERPROFILE at a tmp_path and write fake transcript
# JSONLs containing real and decoy (prose-mention) lines.

def _compact_boundary_line(trigger="auto"):
    return {
        "type": "system",
        "subtype": "compact_boundary",
        "timestamp": "2026-07-14T16:14:33.264Z",
        "uuid": "ad9d989e-0000-0000-0000-000000000000",
        "compactMetadata": {"trigger": trigger, "preTokens": 1002029, "durationMs": 63248},
    }


class TestCompactionEvents:
    def setup_method(self):
        # Every test starts with a cold cache so a prior test's tmp_path result
        # can't leak in via the TTL.
        agg._COMPACTION_CACHE.update(t=0.0, v=None)

    def teardown_method(self):
        agg._COMPACTION_CACHE.update(t=0.0, v=None)

    def test_missing_projects_dir_returns_data_gap_not_fake_zero(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        result = agg._compaction_events([])
        assert result["val"] is None
        assert result["data_gap"] is True
        assert result["calibrated"] is True

    def test_projects_dir_with_no_compaction_returns_real_zero_not_data_gap(self, tmp_path, monkeypatch):
        # A directory that exists but has no compact_boundary records is a genuine
        # zero measurement, never a data gap — distinguishes "read the source,
        # genuinely 0" from "could not read the source".
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        projects_dir = tmp_path / ".claude" / "projects"
        _write_transcript(projects_dir, "s1.jsonl", [{"type": "user", "message": {}}])
        result = agg._compaction_events([])
        assert result["val"] == 0
        assert "data_gap" not in result
        assert result["calibrated"] is True

    def test_counts_real_structural_compact_boundary_records(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        projects_dir = tmp_path / ".claude" / "projects"
        _write_transcript(projects_dir, "s1.jsonl", [
            {"type": "user", "message": {"content": "hi"}},
            _compact_boundary_line(),
        ])
        result = agg._compaction_events([])
        assert result["val"] == 1
        assert result["calibrated"] is True

    def test_prose_mentions_of_compact_are_never_counted(self, tmp_path, monkeypatch):
        # A naive substring/regex match for "compact" would fabricate hundreds of
        # hits from sessions merely discussing compaction; only the structural
        # type=="system"+subtype=="compact_boundary" pair may count.
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        projects_dir = tmp_path / ".claude" / "projects"
        _write_transcript(projects_dir, "s1.jsonl", [
            {"type": "assistant", "message": {"content": [
                {"type": "text", "text": "Discussing Compaction_Events and compact_boundary handling."}
            ]}},
            {"type": "user", "message": {"content": "please compact this summary"}},
        ])
        result = agg._compaction_events([])
        assert result["val"] == 0
        assert "data_gap" not in result

    def test_wrong_subtype_on_system_record_not_counted(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        projects_dir = tmp_path / ".claude" / "projects"
        _write_transcript(projects_dir, "s1.jsonl", [
            {"type": "system", "subtype": "other_boundary", "uuid": "x"},
        ])
        result = agg._compaction_events([])
        assert result["val"] == 0

    def test_sums_across_multiple_files(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        projects_dir = tmp_path / ".claude" / "projects"
        _write_transcript(projects_dir, "s1.jsonl", [_compact_boundary_line()])
        _write_transcript(projects_dir, "s2.jsonl", [_compact_boundary_line(trigger="manual")])
        result = agg._compaction_events([])
        assert result["val"] == 2

    def test_ignores_malformed_lines(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        projects_dir = tmp_path / ".claude" / "projects"
        proj = projects_dir / "proj1"
        proj.mkdir(parents=True)
        path = proj / "s1.jsonl"
        good = json.dumps(_compact_boundary_line())
        path.write_text(good + "\nnot valid json compact_boundary\n", encoding="utf-8")
        result = agg._compaction_events([])
        assert result["val"] == 1

    def test_ignores_records_argument_entirely(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        projects_dir = tmp_path / ".claude" / "projects"
        _write_transcript(projects_dir, "s1.jsonl", [_compact_boundary_line()])
        fake_records = [{"total_cost": 999.0, "model_tier": "CLOUD"}] * 50
        result = agg._compaction_events(fake_records)
        assert result["val"] == 1

    def test_registered_in_registry_under_brush_as_auto_count(self):
        entry = next((e for e in agg.REGISTRY if e[2] == "Compaction_Events"), None)
        assert entry is not None, "Compaction_Events must be registered in aggregate.REGISTRY"
        pillar, group, key, reducer, tier, is_percent, is_count = entry
        assert pillar == "brush"
        assert tier == "AUTO"
        assert is_percent is False
        assert is_count is True
        assert reducer is agg._compaction_events

    def test_build_pillars_reports_live_not_simulated(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        projects_dir = tmp_path / ".claude" / "projects"
        _write_transcript(projects_dir, "s1.jsonl", [_compact_boundary_line()])
        pillars = agg.build_pillars([])
        env = pillars["brush"]["Token Efficiency"]["Compaction_Events"]
        assert env["is_simulated"] is False
        assert env["tier"] == "AUTO"
        assert env["val"] != "—"  # not the "—" no-data placeholder


# ── Daemon_Restart_Count (AUTO-012) ────────────────────────────────────────────
# Real source is service_supervisor.py's own log (~/.claude/data/
# service_supervisor.log), one line per event: "<ISO-ts> <service>: <message>".
# Prior cycles scanned state/autonomic_events.jsonl, which this supervisor never
# writes to — see _daemon_restart_count.

def _supervisor_log(tmp_path, lines):
    data_dir = tmp_path / ".claude" / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    path = data_dir / "service_supervisor.log"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


class TestDaemonRestartCount:
    def test_missing_log_file_returns_data_gap_not_fake_zero(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        result = agg._daemon_restart_count([])
        assert result["val"] is None
        assert result["data_gap"] is True
        assert result["calibrated"] is True

    def test_log_with_restarts_returns_correct_count(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _supervisor_log(tmp_path, [
            "2026-07-06T17:48:12 qdrant: spawn failed — binary not on PATH",
            "2026-07-06T21:31:57 qdrant: restart successful",
            "2026-07-06T21:32:03 ollama: restart successful",
        ])
        result = agg._daemon_restart_count([])
        assert result["val"] == 2
        assert result["calibrated"] is True
        assert "data_gap" not in result
        assert "2 successful restarts" in result["detail"]
        assert "1 failed spawn attempts" in result["detail"]

    def test_log_with_only_failures_returns_honest_zero(self, tmp_path, monkeypatch):
        # An existing log with zero restart lines is an honest 0, not a data gap.
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _supervisor_log(tmp_path, [
            "2026-07-16T04:25:32 qdrant: spawn failed — binary not on PATH",
            "2026-07-16T04:44:33 qdrant: spawn failed — binary not on PATH",
        ])
        result = agg._daemon_restart_count([])
        assert result["val"] == 0
        assert result["calibrated"] is True
        assert "data_gap" not in result
        assert "0 successful restarts" in result["detail"]
        assert "2 failed spawn attempts" in result["detail"]

    def test_malformed_lines_are_skipped_not_crashed(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _supervisor_log(tmp_path, [
            "",
            "not a valid supervisor log line at all",
            "2026-07-06T21:31:57 qdrant: restart successful",
            "   ",
        ])
        result = agg._daemon_restart_count([])
        assert result["val"] == 1
        assert "data_gap" not in result

    def test_ignores_records_argument_entirely(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _supervisor_log(tmp_path, ["2026-07-06T21:31:57 qdrant: restart successful"])
        fake_records = [{"total_cost": 999.0, "model_tier": "CLOUD"}] * 50
        result = agg._daemon_restart_count(fake_records)
        assert result["val"] == 1

    def test_registered_in_registry_under_bow_as_auto_count(self):
        entry = next((e for e in agg.REGISTRY if e[2] == "Daemon_Restart_Count"), None)
        assert entry is not None, "Daemon_Restart_Count must be registered in aggregate.REGISTRY"
        pillar, group, key, reducer, tier, is_percent, is_count = entry
        assert pillar == "bow"
        assert group == "Autonomic"
        assert tier == "AUTO"
        assert is_percent is False
        assert is_count is True
        assert reducer is agg._daemon_restart_count

    def test_build_pillars_reports_live_not_simulated(self, tmp_path, monkeypatch):
        monkeypatch.setenv("USERPROFILE", str(tmp_path))
        _supervisor_log(tmp_path, [
            "2026-07-06T21:31:57 qdrant: restart successful",
            "2026-07-06T21:32:03 ollama: restart successful",
        ])
        pillars = agg.build_pillars([])
        env = pillars["bow"]["Autonomic"]["Daemon_Restart_Count"]
        assert env["is_simulated"] is False
        assert env["tier"] == "AUTO"
        assert env["val"] != "—"


# ── Hygiene trio: Stale_Branch_Count / Lane_Pending_Age / Approved_Unexecuted_HITL ──
# Each inner `_*` reducer returns an int, -1 = source missing; the r_* wrapper must
# turn -1 into a SIMULATED envelope, never into a zero.

_HYGIENE_TRIO = [
    # (metric key, r_ wrapper name, inner reducer name, expected error fragment)
    ("Stale_Branch_Count", "r_stale_branch_count", "_stale_branch_count", "not a git checkout"),
    ("Lane_Pending_Age", "r_lane_pending_age", "_lane_pending_age", "ledger missing"),
    ("Approved_Unexecuted_HITL", "r_approved_unexecuted_hitl", "_approved_unexecuted_hitl", "hitl_queue"),
]


@pytest.fixture(autouse=True)
def _reset_stale_branch_cache(monkeypatch):
    """r_stale_branch_count memoizes for 300s; every test here wants a fresh read."""
    monkeypatch.setattr(agg, "_STALE_BRANCH_CACHE", {"t": 0.0, "v": None})


@pytest.mark.parametrize("key,wrapper,inner,err_fragment", _HYGIENE_TRIO)
class TestHygieneTrioWiring:
    def test_registered_in_registry_under_bow_autonomic_as_auto_count(self, key, wrapper, inner, err_fragment):
        entry = next((e for e in agg.REGISTRY if e[2] == key), None)
        assert entry is not None, f"{key} must be a row in aggregate.REGISTRY (not the scout _set block)"
        pillar, group, _key, reducer, tier, is_percent, is_count = entry
        assert (pillar, group, tier) == ("bow", "Autonomic", "AUTO")
        assert is_percent is False
        assert is_count is True
        assert callable(reducer)
        assert reducer is getattr(agg, wrapper)

    def test_metric_config_grades_lower_with_a_remediation_route(self, key, wrapper, inner, err_fragment):
        from agentica_core import insights
        cfg = insights.METRIC_CONFIG[key]
        assert cfg["dir"] == "lower"
        assert cfg["auto_remediable"] is False  # every fix here is a human merge/archive
        assert key in insights.METRIC_RULES
        assert insights.REMEDIATION[key]["command"].startswith("/")
        assert insights._GRADED_METRIC_PILLARS[key] == ("bow",)

    def test_non_negative_reading_emits_live_auto(self, key, wrapper, inner, err_fragment, monkeypatch):
        monkeypatch.setattr(agg, inner, lambda records, repo_root, now=None: 42)
        result = getattr(agg, wrapper)([])
        assert result == {"val": 42, "calibrated": True}
        env = agg.build_pillars([])["bow"]["Autonomic"][key]
        assert env["is_simulated"] is False
        assert env["tier"] == "AUTO"
        assert env["val"] == "42"

    def test_zero_reading_is_an_honest_live_zero(self, key, wrapper, inner, err_fragment, monkeypatch):
        monkeypatch.setattr(agg, inner, lambda records, repo_root, now=None: 0)
        env = agg.build_pillars([])["bow"]["Autonomic"][key]
        assert env["is_simulated"] is False
        assert env["val"] == "0"

    def test_missing_source_grades_simulated_never_zero(self, key, wrapper, inner, err_fragment, monkeypatch):
        monkeypatch.setattr(agg, inner, lambda records, repo_root, now=None: -1)
        result = getattr(agg, wrapper)([])
        assert result["val"] is None
        assert result["calibrated"] is False
        assert "source unavailable" in result["error"]
        assert err_fragment in result["error"]
        env = agg.build_pillars([])["bow"]["Autonomic"][key]
        assert env["is_simulated"] is True
        assert env["tier"] == "SIMULATED"
        assert env["val"] == "—"

    def test_wrapper_ignores_records_and_reads_the_order_samurai_root(self, key, wrapper, inner, err_fragment, monkeypatch):
        seen = {}

        def fake(records, repo_root, now=None):
            seen["records"] = records
            seen["root"] = repo_root
            return 7

        monkeypatch.setattr(agg, inner, fake)
        getattr(agg, wrapper)([{"total_cost": 1.0}] * 5)
        assert seen["records"] == []  # telemetry is not this metric's source
        assert seen["root"] == agg._ORDER_SAMURAI_ROOT


class TestStaleBranchCountCache:
    def test_second_call_inside_ttl_reuses_the_reading(self, monkeypatch):
        calls = []
        monkeypatch.setattr(agg, "_stale_branch_count", lambda records, repo_root, now=None: calls.append(1) or 88)
        first = agg.r_stale_branch_count([])
        second = agg.r_stale_branch_count([])
        assert first == second == {"val": 88, "calibrated": True}
        assert len(calls) == 1
        second["val"] = 0  # callers get a copy; the cached envelope must not be mutable through it
        assert agg.r_stale_branch_count([])["val"] == 88

    def test_expired_ttl_rereads_and_a_missing_source_is_not_cached_as_live(self, monkeypatch):
        readings = iter([88, -1])
        monkeypatch.setattr(agg, "_stale_branch_count", lambda records, repo_root, now=None: next(readings))
        assert agg.r_stale_branch_count([])["val"] == 88
        agg._STALE_BRANCH_CACHE["t"] -= agg._STALE_BRANCH_TTL_S + 1
        assert agg.r_stale_branch_count([])["val"] is None


class TestApprovedUnexecutedHitlSource:
    @pytest.mark.parametrize("items", [
        pytest.param([], id="empty"),
        pytest.param([{"source": "factory", "status": "approved",
                       "approved_at": "2026-01-01T00:00:00Z"}], id="stale-factory"),
    ])
    def test_buyer_queue_is_unavailable(self, tmp_path, monkeypatch, items):
        monkeypatch.setattr(agg, "_in_monorepo_layout", lambda: False)
        (tmp_path / "state").mkdir()
        (tmp_path / "state" / "hitl_queue.json").write_text(
            json.dumps({"items": items}), encoding="utf-8",
        )

        assert agg._approved_unexecuted_hitl(
            [], tmp_path, now=datetime(2026, 10, 6, tzinfo=timezone.utc),
        ) == -1

    @pytest.mark.parametrize("items", [
        pytest.param([], id="empty"),
        pytest.param([{"source": "factory", "status": "approved",
                       "approved_at": "2026-01-01T00:00:00Z"}], id="stale-factory"),
    ])
    def test_buyer_queue_builds_simulated_envelope(self, tmp_path, monkeypatch, items):
        monkeypatch.setattr(agg, "_in_monorepo_layout", lambda: False)
        (tmp_path / "state").mkdir()
        (tmp_path / "state" / "hitl_queue.json").write_text(
            json.dumps({"items": items}), encoding="utf-8",
        )
        monkeypatch.setattr(agg, "_ORDER_SAMURAI_ROOT", tmp_path)
        # Exercise the real wrapper without reading unrelated metric sources.
        monkeypatch.setattr(agg, "REGISTRY", [
            row for row in agg.REGISTRY if row[2] == "Approved_Unexecuted_HITL"
        ])
        monkeypatch.setattr(agg, "_vault_health_metrics", lambda: None)

        env = agg.build_pillars([])["bow"]["Autonomic"]["Approved_Unexecuted_HITL"]

        assert env["is_simulated"] is True
        assert env["val"] == "—"
        assert env["tier"] == "SIMULATED"

    @pytest.mark.parametrize("body", [
        pytest.param({}, id="missing-items"),
        pytest.param({"items": None}, id="null-items"),
        pytest.param({"items": {}}, id="object-items"),
        pytest.param([], id="top-level-list"),
    ])
    def test_queue_requires_items_list(self, tmp_path, monkeypatch, body):
        monkeypatch.setattr(agg, "_in_monorepo_layout", lambda: True)
        (tmp_path / "state").mkdir()
        (tmp_path / "state" / "hitl_queue.json").write_text(json.dumps(body), encoding="utf-8")

        assert agg._approved_unexecuted_hitl([], tmp_path) == -1

    @pytest.mark.parametrize("items,expected", [
        pytest.param([], 0, id="empty"),
        pytest.param([{"source": "factory", "status": "approved",
                       "approved_at": "2026-01-01T00:00:00Z"}], 1, id="stale-factory"),
        pytest.param([{"source": "factory", "status": "approved",
                       "approved_at": "2026-01-01T00:00:00Z",
                       "executing_at": "2026-01-02T00:00:00Z"}], 0, id="executing"),
        pytest.param([{"source": "manual", "status": "approved",
                       "approved_at": "2026-01-01T00:00:00Z"}], 0, id="non-factory"),
        pytest.param([{"source": "factory", "status": "pending",
                       "approved_at": "2026-01-01T00:00:00Z"}], 0, id="not-approved"),
    ])
    def test_monorepo_counts_only_stale_unexecuted_factory_approvals(
        self, tmp_path, monkeypatch, items, expected,
    ):
        monkeypatch.setattr(agg, "_in_monorepo_layout", lambda: True)
        (tmp_path / "state").mkdir()
        (tmp_path / "state" / "hitl_queue.json").write_text(
            json.dumps({"items": items}), encoding="utf-8",
        )

        assert agg._approved_unexecuted_hitl(
            [], tmp_path, now=datetime(2026, 10, 6, tzinfo=timezone.utc),
        ) == expected

    @pytest.mark.parametrize("body", [
        pytest.param(None, id="missing-file"),
        pytest.param('{"items": [', id="invalid-json"),
    ])
    def test_missing_or_invalid_queue_is_unavailable(self, tmp_path, monkeypatch, body):
        monkeypatch.setattr(agg, "_in_monorepo_layout", lambda: True)
        if body is not None:
            (tmp_path / "state").mkdir()
            (tmp_path / "state" / "hitl_queue.json").write_text(body, encoding="utf-8")

        assert agg._approved_unexecuted_hitl([], tmp_path) == -1
