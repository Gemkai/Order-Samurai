import { useState } from "react"
import { motion, AnimatePresence } from "motion/react"
import {
  Terminal,
  Copy,
  Check,
  Lock,
  CheckCircle2,
  X,
  Sparkles,
  Eye,
  AlertTriangle,
  Zap,
  Play,
  ArrowRight,
  ShieldCheck,
  Users,
  ExternalLink,
  ChevronRight,
  Info
} from "lucide-react"
import { IconTorii, IconKatana, IconShuriken, IconFan, IconArmor } from "./SamuraiIcons"

interface LandingPageProps {
  onOpenDashboard: () => void
}

export function LandingPage({ onOpenDashboard }: LandingPageProps) {
  const [copied, setCopied] = useState(false)
  const [installTab, setInstallTab] = useState<"curl" | "clone">("curl")
  const [contactModalOpen, setContactModalOpen] = useState(false)
  const [activePillarTooltip, setActivePillarTooltip] = useState<string | null>(null)

  const quickstartCommands = {
    curl: "curl -fsSL https://www.ordersamurai.ai/install.sh | bash",
    clone: "git clone https://github.com/Gemkai/order-samurai.git && cd order-samurai && ./bin/samurai install"
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(quickstartCommands[installTab])
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Deduplicated Live Telemetry Feed Pool (Rec 6)
  const telemetryFeed = [
    { type: "SWORD", label: "KILL CHAIN", text: "Blocked Chain 13 indirect prompt injection in git diff", source: "hooks/prompt_injection_guard.py", color: "#ef4444" },
    { type: "BRUSH", label: "SECRET SCRUB", text: "Redacted AWS_SECRET_ACCESS_KEY from subagent stdout in 2ms", source: "hooks/secret_scrubber_realtime.py", color: "#ef4444" },
    { type: "BOW", label: "WORKTREE SANDBOX", text: "Remediation verified in ephemeral git branch before staging patch", source: "execution/worktree_patch_runner.py", color: "#3b82f6" },
    { type: "ARTS", label: "DOC CHECK", text: "Deterministic doc-parity check reports link inconsistencies for review", source: "execution/verify_doc_parity.py", color: "#8b5cf6" },
    { type: "SWORD", label: "LOOP BREAKER", text: "Halted repetitive subagent retry loop on zero-impact metric", source: "agentica_core/skill_no_impact.py", color: "#ef4444" },
    { type: "BRUSH", label: "RECONCILER", text: "Completed 10-second daily state & falsifiability reconciliation", source: "bin/reconcile_state.py", color: "#ef4444" }
  ]

  return (
    <div className="min-h-screen bg-[#080b10] text-[#e2e8f0] font-sans overflow-x-hidden selection:bg-[#ef4444] selection:text-white">
      {/* Background Glow Overlay — Muted Glass Atmosphere */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[20%] w-[500px] h-[500px] bg-gradient-to-br from-[#ef4444]/10 via-slate-900/10 to-transparent rounded-full blur-[140px]" />
        <div className="absolute top-[40%] right-[-5%] w-[600px] h-[600px] bg-gradient-to-tl from-slate-900/30 via-slate-900/10 to-transparent rounded-full blur-[140px]" />
      </div>

      {/* Navigation Bar */}
      <nav className="relative z-50 border-b border-white/10 bg-[#080b10]/80 backdrop-blur-md sticky top-0">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.jpg" alt="Order Samurai" className="w-12 h-12 rounded-xl object-contain bg-black border border-white/10 shadow-md shadow-[#ef4444]/15" />
            <div>
              <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
                ORDER SAMURAI
              </span>
              <span className="ml-2 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider bg-slate-800 text-slate-300 border border-white/10 rounded-full">
                v1.0.2 Open Core
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
            <a href="#problem" className="hover:text-white transition-colors">Risk Breakdown</a>
            <a href="#showcase" className="hover:text-white transition-colors">Live Simulation</a>
            <a href="#features" className="hover:text-white transition-colors">4 Pillars</a>
            <a href="#journal" className="hover:text-white transition-colors">Journal</a>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={onOpenDashboard}
              className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-200 bg-slate-900 hover:bg-slate-800 border border-white/10 rounded-lg transition-all shadow-sm group"
            >
              <Eye size={16} className="text-slate-400 group-hover:text-white transition-colors" />
              Explore Live Governance
            </button>

            {/* Rec 4 — One-Accent Discipline: Crimson Reserved for Buy / Shield CTA */}
            <a
              href="order-samurai-core.zip"
              download
              className="flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-[#ef4444] hover:bg-[#dc2626] rounded-lg transition-all shadow-lg shadow-[#ef4444]/25 hover:shadow-[#ef4444]/40"
            >
              <ShieldCheck size={16} />
              Download Free Core (.zip)
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section — Rec 1 (Conclusion Headline) & Rec 2 (Plain-English Tagline) & Rec 8 (60s Audit Artifact) */}
      <section className="relative z-10 pt-16 pb-16 max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-12 max-w-6xl mx-auto">
          <div className="flex-1 text-left">
            {/* Persona Target Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-white/15 text-xs font-medium text-slate-300 mb-6"
            >
              <Users size={14} className="text-[#ef4444]" />
              LOCAL GOVERNANCE &amp; SECURITY FOR CODING FLEETS
            </motion.div>

            {/* Rec 1 — Headline leads with the outcome / payoff conclusion */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.15]"
            >
              Helps prevent agents from exposing keys, exceeding budgets, or{" "}
              <span className="bg-gradient-to-r from-[#ef4444] via-[#f97316] to-[#eab308] bg-clip-text text-transparent">
                running dangerous commands.
              </span>
            </motion.h1>

            {/* Rec 2 — Plain-English Category Line before jargon */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mt-6 space-y-3 max-w-xl"
            >
              <p className="text-base font-semibold text-white/95 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#ef4444] animate-pulse" />
                Local-first governance and security for autonomous agent fleets.
              </p>
              <p className="text-sm text-slate-300 leading-relaxed">
                Order Samurai intercepts prompt injections, scrubs credentials in real time, and monitors operational health — local by default, with zero product telemetry collected by Order Samurai.
              </p>
            </motion.div>

            {/* Hero CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              className="mt-8 flex flex-col sm:flex-row items-center gap-4"
            >
              {/* Rec 4 — Primary CTA Accent */}
              <a
                href="order-samurai-core.zip"
                download
                className="w-full sm:w-auto px-8 py-3.5 bg-[#ef4444] hover:bg-[#dc2626] text-white rounded-xl font-bold text-sm shadow-xl shadow-[#ef4444]/25 flex items-center justify-center gap-2 transition-all hover:scale-105"
              >
                <ShieldCheck size={18} />
                Download Free Core (.zip)
                <ArrowRight size={16} />
              </a>
              <button
                onClick={onOpenDashboard}
                className="w-full sm:w-auto px-8 py-3.5 bg-slate-900 hover:bg-slate-800 border border-white/10 text-slate-200 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
              >
                <Play size={16} className="text-slate-400" />
                Explore Interactive Demo
              </button>
            </motion.div>
            <p className="mt-3 text-xs text-slate-400 font-mono">
              ⚡ Local-First • Fail-Closed Security • macOS / Linux / Claude Code
            </p>
          </div>

          {/* Rec 8 — Real Governance Report Artifact Above the Fold */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="flex-shrink-0 w-full sm:w-80 lg:w-[440px]"
          >
            <div className="bg-[#0b111d] border border-white/15 rounded-2xl p-5 shadow-2xl relative overflow-hidden backdrop-blur-xl">
              {/* Artifact Header */}
              <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#ef4444]" />
                  <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">FIRST-INSTALL AUDIT</span>
                </div>
                <span className="px-2 py-0.5 text-[10px] font-mono font-semibold bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/30 rounded-md">
                  &lt; 60s REPORT
                </span>
              </div>

              {/* Sample Governance Audit Output */}
              <div className="space-y-3 font-mono text-xs">
                <div className="p-3 bg-slate-950/90 rounded-xl border border-white/5 space-y-2">
                  <div className="text-slate-400 flex items-center justify-between text-[11px]">
                    <span>Target Machine: local (~/.samurai)</span>
                    <span className="text-slate-300 font-bold">FAIL-CLOSED</span>
                  </div>
                  <div className="pt-2 border-t border-white/5 space-y-1.5">
                    <div className="flex items-center justify-between text-[#ef4444]">
                      <span className="flex items-center gap-1.5">
                        <AlertTriangle size={13} />
                        Prompt Injections:
                      </span>
                      <span className="font-bold">2 Intercepted</span>
                    </div>
                    <div className="flex items-center justify-between text-amber-400">
                      <span className="flex items-center gap-1.5">
                        <Lock size={13} />
                        Secret Leakage:
                      </span>
                      <span className="font-bold">1 Scrubbed (.env)</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <Zap size={13} />
                        Spend Delta:
                      </span>
                      <span className="font-bold text-white">$318.40/wk saved</span>
                    </div>
                  </div>
                </div>

                <div className="p-2.5 bg-slate-900/60 rounded-lg border border-white/5 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Reads existing logs automatically</span>
                  <span className="text-white font-semibold flex items-center gap-1">
                    Zero Setup <Check size={12} className="text-[#ef4444]" />
                  </span>
                </div>
              </div>

              {/* Interactive Report Trigger */}
              <button
                onClick={onOpenDashboard}
                className="mt-4 w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 border border-white/10 transition-colors"
              >
                Inspect Live Audit Report
                <ChevronRight size={14} />
              </button>
            </div>
          </motion.div>
        </div>

        {/* Quickstart Terminal Widget */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="mt-12 max-w-2xl mx-auto bg-[#0d131f] border border-white/10 rounded-2xl p-4 text-left shadow-2xl backdrop-blur-xl"
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <Terminal size={18} className="text-[#ef4444]" />
              <span className="text-xs font-mono text-slate-300">Install Order Samurai Open Core</span>
            </div>
            <div className="flex gap-2">
              {(["curl", "clone"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setInstallTab(tab)}
                  className={`px-2.5 py-1 text-[11px] font-mono rounded transition-all ${
                    installTab === tab ? "bg-[#ef4444] text-white font-bold" : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between gap-4 bg-slate-950/80 border border-white/5 p-3.5 rounded-xl font-mono text-xs sm:text-sm text-slate-200 overflow-x-auto">
            <span className="truncate text-slate-300">{quickstartCommands[installTab]}</span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10 rounded-lg text-xs font-bold transition-all shrink-0"
            >
              {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              {copied ? "Command Copied!" : "Copy Command"}
            </button>
          </div>

          <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-slate-500">
            <div className="flex items-center gap-2">
              <CheckCircle2 size={12} className="text-slate-400" />
              <span>No Product Telemetry • Staged Patch Review • Public CI Evidence</span>
            </div>
            <span>Setup and scan time varies</span>
          </div>
        </motion.div>
      </section>

      {/* Rec 6 — Deduplicated Activity Telemetry Feed Section */}
      <section className="relative z-10 py-6 border-y border-white/5 bg-[#06090e]">
        <div className="max-w-7xl mx-auto px-6 overflow-x-auto">
          <div className="flex items-center gap-6 whitespace-nowrap min-w-max">
            <span className="text-[11px] font-mono text-slate-500 uppercase tracking-widest flex items-center gap-2 shrink-0">
              <span className="w-2 h-2 rounded-full bg-[#ef4444] animate-ping" />
              ILLUSTRATIVE EVENT STREAM:
            </span>
            {telemetryFeed.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2 font-mono text-xs text-slate-400 bg-slate-950/60 border border-white/5 px-3 py-1.5 rounded-lg shrink-0">
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-slate-800 text-slate-300">{item.label}</span>
                <span className="text-slate-200">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Problem / Agitation / Solution Framework */}
      <section id="problem" className="relative z-10 py-20 border-t border-white/10 bg-[#06090e]/90">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="px-3 py-1 text-xs font-mono font-semibold uppercase tracking-wider bg-slate-900 text-slate-300 border border-white/10 rounded-full">
              Why Agent Security Matters
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">
              Autonomous Agents Have Root Access To Your Shell. <br />
              <span className="text-[#ef4444]">Are You Protected?</span>
            </h2>
            <p className="mt-4 text-slate-400 text-base">
              Running coding agents without deterministic execution boundaries exposes your local workspace to undetected compromise.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-[#0b0f17] border border-white/10 rounded-2xl p-8 relative shadow-xl">
              <div className="w-12 h-12 rounded-xl bg-slate-900 border border-white/10 text-slate-300 flex items-center justify-center mb-6">
                <AlertTriangle size={24} className="text-[#ef4444]" />
              </div>
              <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest">1. The Problem</span>
              <h3 className="text-xl font-bold text-white mt-2">Unchecked Agent Execution</h3>
              <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                Coding agents like Claude Code execute arbitrary shell scripts, install unvetted NPM packages, and parse untrusted remote files with user privileges.
              </p>
            </div>

            <div className="bg-[#0b0f17] border border-white/10 rounded-2xl p-8 relative shadow-xl">
              <div className="w-12 h-12 rounded-xl bg-slate-900 border border-white/10 text-slate-300 flex items-center justify-center mb-6">
                <Zap size={24} className="text-[#ef4444]" />
              </div>
              <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest">2. The Agitation</span>
              <h3 className="text-xl font-bold text-white mt-2">Silent Exfiltration & Injections</h3>
              <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                A single indirect prompt injection in a git repo can trick your agent into exfiltrating your <code className="text-amber-300">.env</code> keys, SSH tokens, or database credentials.
              </p>
            </div>

            <div className="bg-[#0b0f17] border border-[#ef4444]/30 rounded-2xl p-8 relative shadow-xl bg-gradient-to-b from-[#ef4444]/[0.03] to-transparent">
              <div className="w-12 h-12 rounded-xl bg-slate-900 border border-[#ef4444]/40 text-[#ef4444] flex items-center justify-center mb-6">
                <ShieldCheck size={24} />
              </div>
              <span className="text-xs font-mono font-bold text-[#ef4444] uppercase tracking-widest">3. The Solution</span>
              <h3 className="text-xl font-bold text-white mt-2">Order Samurai Local Guard</h3>
              <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                Order Samurai intercepts subagent calls in real-time, redacts secrets from stdout, blocks malicious CLI payloads fail-closed, and tracks empirical ROI local-first.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Target Buyer Personas */}
      <section id="dojo-pitches" className="relative z-10 py-20 border-t border-white/5 bg-[#090d16]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="px-3 py-1 text-xs font-mono font-semibold uppercase tracking-wider bg-slate-900 text-slate-300 border border-white/10 rounded-full">
              Dojo Target Personas
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">
              Engineered for Solopreneurs, Harness Builders, & DevSecOps
            </h2>
            <p className="mt-4 text-slate-400 text-base">
              Whether running raw agents or building custom harnesses, the Dojo enforces discipline where prompts fail.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="bg-[#0e1422]/60 border border-white/10 rounded-2xl p-8 hover:border-slate-500 transition-all flex flex-col justify-between shadow-xl backdrop-blur-sm group">
              <div>
                <div className="w-12 h-12 rounded-xl bg-slate-900 border border-white/10 text-slate-300 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Users size={24} />
                </div>
                <h3 className="text-xl font-bold text-white">Solo Developers: Protect Your Single-Point Business</h3>
                <p className="mt-4 text-xs text-slate-400 leading-relaxed">
                  As a solo builder, AI agents act as your entire team. A single unchecked command can break client DBs or leak API keys. Order Samurai acts as your silent local co-pilot.
                </p>
              </div>
              <div className="mt-8 pt-4 border-t border-white/5 font-mono text-[10px] text-slate-500">
                // Safety rails for one-person operations
              </div>
            </div>

            <div className="bg-[#0e1422]/60 border border-white/10 rounded-2xl p-8 hover:border-slate-500 transition-all flex flex-col justify-between shadow-xl backdrop-blur-sm group">
              <div>
                <div className="w-12 h-12 rounded-xl bg-slate-900 border border-white/10 text-slate-300 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Terminal size={24} />
                </div>
                <h3 className="text-xl font-bold text-white">Harness Builders: Secure Agent Runtimes</h3>
                <p className="mt-4 text-xs text-slate-400 leading-relaxed">
                  Developing custom wrappers or CLI harnesses for Claude, Codex, or Gemini? Order Samurai acts as local middleware, redacting credentials without adding pipeline latency.
                </p>
              </div>
              <div className="mt-8 pt-4 border-t border-white/5 font-mono text-[10px] text-slate-500">
                // Sits seamlessly between harness & shell
              </div>
            </div>

            <div className="bg-[#0e1422]/60 border border-white/10 rounded-2xl p-8 hover:border-slate-500 transition-all flex flex-col justify-between shadow-xl backdrop-blur-sm group">
              <div>
                <div className="w-12 h-12 rounded-xl bg-slate-900 border border-white/10 text-slate-300 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Eye size={24} />
                </div>
                <h3 className="text-xl font-bold text-white">DevSecOps: Observe Invisible Security</h3>
                <p className="mt-4 text-xs text-slate-400 leading-relaxed">
                  Security is usually invisible until a breach occurs. Order Samurai renders tangible, empirical telemetry: exfiltration blocks, spend saves, and execution kills.
                </p>
              </div>
              <div className="mt-8 pt-4 border-t border-white/5 font-mono text-[10px] text-slate-500">
                // Empirical security metrics you can see
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Rec 3, 4, 5 — Four Pillars with ~40% Density Reduction, One-Accent Discipline, and CALIBRATING Separation */}
      <section id="features" className="relative z-10 py-20 border-t border-white/5 bg-[#0b0f17]/60">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-white tracking-tight">Four Business Pillars</h2>
            <p className="mt-3 text-slate-400 text-base">
              Empirical governance metrics evaluated directly from local execution logs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* SWORD (MEASURED) */}
            <div className="bg-[#0f172a]/60 border border-[#ef4444]/40 rounded-2xl p-6 transition-all backdrop-blur-sm shadow-xl relative">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <IconKatana size={20} color="#ef4444" />
                  <span className="text-xs font-mono font-bold text-white uppercase">SWORD</span>
                </div>

                {/* Rec 5 — MEASURED Solid Badge */}
                <span className="px-2.5 py-1 text-[10px] font-bold bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/40 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#ef4444]" />
                  MEASURED
                </span>
              </div>

              {/* Rec 3 — Lead with the Metric Callout */}
              <div className="my-4">
                <span className="text-4xl font-extrabold text-white">14</span>
                <span className="ml-2 text-xs font-mono text-slate-400">chains blocked/wk</span>
              </div>

              <h3 className="text-sm font-bold text-white">Kill Chains Disrupted</h3>
              <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
                Interception of indirect prompt injections and credential exfiltration.
              </p>

              <div className="mt-4 pt-3 border-t border-white/10 text-[10px] font-mono text-slate-500 flex items-center justify-between">
                <span>Audit: state/kill_chain_events.jsonl</span>
                <button
                  onClick={() => setActivePillarTooltip(activePillarTooltip === "sword" ? null : "sword")}
                  className="text-slate-400 hover:text-white"
                >
                  <Info size={13} />
                </button>
              </div>

              {activePillarTooltip === "sword" && (
                <div className="mt-2 p-2 bg-slate-950 rounded text-[10px] font-mono text-slate-300 border border-white/10">
                  Atomic append log with hook source & confidence scoring.
                </div>
              )}
            </div>

            {/* BOW (CALIBRATING — Ghost / Dashed Style) */}
            <div className="bg-slate-950/40 border border-dashed border-slate-700 rounded-2xl p-6 transition-all backdrop-blur-sm relative">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <IconShuriken size={20} color="#94a3b8" />
                  <span className="text-xs font-mono font-bold text-slate-300 uppercase">BOW</span>
                </div>

                {/* Rec 5 — CALIBRATING Hollow Dot / Dashed Badge */}
                <span className="px-2.5 py-1 text-[10px] font-medium bg-slate-900 text-slate-400 border border-slate-700 border-dashed rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full border border-slate-400" />
                  CALIBRATING
                </span>
              </div>

              {/* Rec 5 — Ghost/Muted Number */}
              <div className="my-4">
                <span className="text-4xl font-bold text-slate-300/90">42.5 hrs</span>
                <span className="ml-2 text-xs font-mono text-slate-500">+12% benchmark</span>
              </div>

              <h3 className="text-sm font-semibold text-slate-200">Agent Time Saved</h3>
              <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
                Wall-clock duration of completed, explicitly approved backlog tasks vs baselines.
              </p>

              <div className="mt-4 pt-3 border-t border-white/10 text-[10px] font-mono text-slate-500 flex items-center justify-between">
                <span>Progress: 12 / 20 calibrated runs</span>
                <button
                  onClick={() => setActivePillarTooltip(activePillarTooltip === "bow" ? null : "bow")}
                  className="text-slate-400 hover:text-white"
                >
                  <Info size={13} />
                </button>
              </div>

              {activePillarTooltip === "bow" && (
                <div className="mt-2 p-2 bg-slate-950 rounded text-[10px] font-mono text-slate-300 border border-white/10">
                  Calibrating model efficiency against standard reference suites.
                </div>
              )}
            </div>

            {/* BRUSH (MEASURED) */}
            <div className="bg-[#0f172a]/60 border border-[#ef4444]/40 rounded-2xl p-6 transition-all backdrop-blur-sm shadow-xl relative">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <IconFan size={20} color="#ef4444" />
                  <span className="text-xs font-mono font-bold text-white uppercase">BRUSH</span>
                </div>

                <span className="px-2.5 py-1 text-[10px] font-bold bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/40 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#ef4444]" />
                  MEASURED
                </span>
              </div>

              <div className="my-4">
                <span className="text-4xl font-extrabold text-white">$318.40</span>
                <span className="ml-2 text-xs font-mono text-slate-400">saved/wk</span>
              </div>

              <h3 className="text-sm font-bold text-white">Actual Cost Savings</h3>
              <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
                Ledger spend tracking & spend-capping delta vs list pricing.
              </p>

              <div className="mt-4 pt-3 border-t border-white/10 text-[10px] font-mono text-slate-500 flex items-center justify-between">
                <span>Audit: state/budget_ledger.json</span>
                <button
                  onClick={() => setActivePillarTooltip(activePillarTooltip === "brush" ? null : "brush")}
                  className="text-slate-400 hover:text-white"
                >
                  <Info size={13} />
                </button>
              </div>

              {activePillarTooltip === "brush" && (
                <div className="mt-2 p-2 bg-slate-950 rounded text-[10px] font-mono text-slate-300 border border-white/10">
                  Direct ledger delta from spend capping & optimized execution.
                </div>
              )}
            </div>

            {/* ARTS (CALIBRATING — Ghost Style) */}
            <div className="bg-slate-950/40 border border-dashed border-slate-700 rounded-2xl p-6 transition-all backdrop-blur-sm relative">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <IconArmor size={20} color="#94a3b8" />
                  <span className="text-xs font-mono font-bold text-slate-300 uppercase">ARTS</span>
                </div>

                <span className="px-2.5 py-1 text-[10px] font-medium bg-slate-900 text-slate-400 border border-slate-700 border-dashed rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full border border-slate-400" />
                  CALIBRATING
                </span>
              </div>

              <div className="my-4">
                <span className="text-4xl font-bold text-slate-300/90">18.2 hrs</span>
                <span className="ml-2 text-xs font-mono text-slate-500">craft gain</span>
              </div>

              <h3 className="text-sm font-semibold text-slate-200">Human Time Saved</h3>
              <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
                Productivity gain from doc parity reduction and skill promotion.
              </p>

              <div className="mt-4 pt-3 border-t border-white/10 text-[10px] font-mono text-slate-500 flex items-center justify-between">
                <span>Progress: 14 / 20 calibrated runs</span>
                <button
                  onClick={() => setActivePillarTooltip(activePillarTooltip === "arts" ? null : "arts")}
                  className="text-slate-400 hover:text-white"
                >
                  <Info size={13} />
                </button>
              </div>

              {activePillarTooltip === "arts" && (
                <div className="mt-2 p-2 bg-slate-950 rounded text-[10px] font-mono text-slate-300 border border-white/10">
                  Documentation latency delta & automated test suite throughput.
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Illustrative workflows; not customer endorsements or performance evidence. */}
      <section id="proof" className="relative z-10 py-20 border-t border-white/5 bg-[#090d15]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-4">Workflows to explore</h2>
            <p className="text-xs text-slate-400 mt-4">Illustrative use cases, not testimonials or measured customer results.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="bg-[#0e1422] border border-white/10 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white">Review dangerous tool actions</h3>
              <p className="text-xs text-slate-300 mt-3">Register and test the supported hooks before relying on their policy checks.</p>
            </div>
            <div className="bg-[#0e1422] border border-white/10 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white">Inspect local fleet health</h3>
              <p className="text-xs text-slate-300 mt-3">Read available telemetry locally. Missing data is not proof of safety; optional third-party review requires opt-in.</p>
            </div>
            <div className="bg-[#0e1422] border border-white/10 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white">Review staged repairs</h3>
              <p className="text-xs text-slate-300 mt-3">Inspect proposed patches and their evidence, then explicitly approve any application.</p>
            </div>
          </div>

          {/* Maintainer Attribution Banner (Rec 10) */}
          <div className="max-w-2xl mx-auto bg-slate-950 border border-white/10 rounded-xl p-4 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Built by <strong>Gemkai</strong> &amp; Order Samurai Contributors</span>
            </div>
            <a
              href="https://github.com/Gemkai/order-samurai"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:underline flex items-center gap-1"
            >
              View GitHub Source <ExternalLink size={12} />
            </a>
          </div>
        </div>
      </section>

      {/* Rec 9 — Published Journal Dispatches */}
      <section id="journal" className="relative z-10 py-20 border-t border-white/5 max-w-7xl mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <span className="px-3 py-1 text-xs font-mono font-semibold uppercase tracking-wider bg-slate-900 text-slate-300 border border-white/10 rounded-full">
              Engineering Journal
            </span>
            <h2 className="text-3xl font-bold text-white tracking-tight mt-3">Dispatches from the Frontier</h2>
            <p className="mt-2 text-xs font-mono text-slate-400">Weekly postmortems on agent governance, real-time AST scrubbing, and fail-closed security.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Issue 01 */}
            <div className="bg-[#0c121e] border border-white/10 rounded-2xl p-6 shadow-xl flex flex-col justify-between hover:border-slate-600 transition-all">
              <div>
                <div className="flex items-center justify-between text-xs font-mono text-slate-500 mb-2">
                  <span>ISSUE #01</span>
                  <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded font-semibold text-[10px]">PUBLISHED</span>
                </div>
                <h3 className="text-base font-bold text-white">Fail-Closed Security for Coding Fleets</h3>
                <p className="mt-2 text-xs text-slate-300 leading-relaxed">
                  Why probabilistic prompt engineering fails under adversarial sweeps, and how local deterministic middleware hooks enforce fail-closed security.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-mono text-[11px]">5 min read</span>
                <button onClick={onOpenDashboard} className="text-[#ef4444] font-semibold hover:underline flex items-center gap-1 text-xs">
                  Read Entry →
                </button>
              </div>
            </div>

            {/* Issue 02 */}
            <div className="bg-[#0c121e] border border-white/10 rounded-2xl p-6 shadow-xl flex flex-col justify-between hover:border-slate-600 transition-all">
              <div>
                <div className="flex items-center justify-between text-xs font-mono text-slate-500 mb-2">
                  <span>ISSUE #02</span>
                  <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded font-semibold text-[10px]">PUBLISHED</span>
                </div>
                <h3 className="text-base font-bold text-white">The LLM Judge Paradox</h3>
                <p className="mt-2 text-xs text-slate-300 leading-relaxed">
                  Why LLM self-evaluations produce flattering hallucinations, and how deterministic bad/clean fixtures restore mathematical ground truth.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-mono text-[11px]">6 min read</span>
                <button onClick={onOpenDashboard} className="text-[#ef4444] font-semibold hover:underline flex items-center gap-1 text-xs">
                  Read Entry →
                </button>
              </div>
            </div>

            {/* Issue 03 */}
            <div className="bg-[#0c121e] border border-white/10 rounded-2xl p-6 shadow-xl flex flex-col justify-between hover:border-slate-600 transition-all">
              <div>
                <div className="flex items-center justify-between text-xs font-mono text-slate-500 mb-2">
                  <span>ISSUE #03</span>
                  <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded font-semibold text-[10px]">PUBLISHED</span>
                </div>
                <h3 className="text-base font-bold text-white">Breaking the Runaway Loop</h3>
                <p className="mt-2 text-xs text-slate-300 leading-relaxed">
                  The anatomy of a 31-cycle overnight retry loop, and how 1-strike loop breakers prevent runaway token burn on non-improving metrics.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-mono text-[11px]">6 min read</span>
                <button onClick={onOpenDashboard} className="text-[#ef4444] font-semibold hover:underline flex items-center gap-1 text-xs">
                  Read Entry →
                </button>
              </div>
            </div>

            {/* Issue 04 */}
            <div className="bg-[#0c121e] border border-white/10 rounded-2xl p-6 shadow-xl flex flex-col justify-between hover:border-slate-600 transition-all">
              <div>
                <div className="flex items-center justify-between text-xs font-mono text-slate-500 mb-2">
                  <span>ISSUE #04</span>
                  <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded font-semibold text-[10px]">PUBLISHED</span>
                </div>
                <h3 className="text-base font-bold text-white">Real-Time AST Secret Scrubbing</h3>
                <p className="mt-2 text-xs text-slate-300 leading-relaxed">
                  Under 2ms latency overhead for high-entropy credential scrubbing across subagent stdout streams before prompts hit remote LLM gateways.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-mono text-[11px]">7 min read</span>
                <button onClick={onOpenDashboard} className="text-[#ef4444] font-semibold hover:underline flex items-center gap-1 text-xs">
                  Read Entry →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Rec 7 — Named Persona Pricing Section */}
      <section id="pricing" className="relative z-10 py-20 border-t border-white/5 max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl font-bold text-white tracking-tight">Simple, Self-Serve Pricing</h2>
          <p className="mt-3 text-slate-400 text-base">
            Start free with Open Core on your workstation. Upgrade to Pro for deeper diagnostics, scheduled checks, and staged repair review.
          </p>

          {/* Rec 7 — Pricing Flat-Rate Stance Line */}
          <div className="mt-4 inline-block px-4 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs font-mono text-slate-300">
            "Your agents' verbosity is your productivity, not our tax — zero token markups."
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-10 max-w-4xl mx-auto">
          {/* Card 1: Free Core — Named Persona: Solo Developers */}
          <div className="bg-[#0d131f] border border-white/10 rounded-2xl p-8 flex flex-col justify-between hover:border-slate-500 transition-all shadow-xl">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400 uppercase tracking-wider font-semibold">Open Source</span>
                <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded">Solo Devs</span>
              </div>
              <h3 className="text-2xl font-bold text-white mt-1">Free Core</h3>
              <p className="text-xs text-slate-400 mt-1 font-mono">For developers auditing local agent logs</p>

              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-extrabold text-white">$0</span>
                <span className="text-xs text-slate-400">/ forever free</span>
              </div>
              <ul className="mt-6 space-y-3 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-slate-400" /> Fail-Closed Checks in Supported Hooks
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-slate-400" /> Secret Redaction in Supported Workflows
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-slate-400" /> 4-Pillar Diagnostics (7-Day Log Window)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-slate-400" /> Manual Staged Patches (.patch for git apply)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-slate-400" /> Local by Default; Optional Review Requires Opt-In
                </li>
              </ul>
            </div>
            <a
              href="order-samurai-core.zip"
              download
              className="mt-8 w-full py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-sm transition-colors border border-white/10 flex items-center justify-center gap-2 text-center"
            >
              <ShieldCheck size={16} />
              Download Free Core (.zip)
            </a>
          </div>

          {/* Card 2: Pro Lifetime — Named Persona: Fleet Operators (Rec 4 Crimson Accent) */}
          <div className="bg-[#0d131f] border-2 border-[#ef4444] rounded-2xl p-8 flex flex-col justify-between relative shadow-2xl shadow-[#ef4444]/15">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-[#ef4444] text-white text-[10px] font-mono font-bold rounded-full uppercase">
              RECOMMENDED FOR FLEETS
            </div>
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-[#ef4444] uppercase tracking-wider font-semibold">PRO VERSION</span>
                <span className="text-[10px] font-mono bg-[#ef4444]/20 text-[#ef4444] px-2 py-0.5 rounded font-bold">Fleet Diagnostics</span>
              </div>
              <h3 className="text-2xl font-bold text-white mt-1">Pro Lifetime</h3>
              <p className="text-xs text-slate-400 mt-1 font-mono">For operators reviewing fleet health</p>

              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-extrabold text-white">$199</span>
                <span className="text-xs text-slate-400">/ one-time payment</span>
              </div>
              <ul className="mt-6 space-y-3 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#ef4444]" /> Everything in Free Core
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#ef4444]" /> Maker-Checker Patch Staging for Human Approval
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#ef4444]" /> Touch ID Biometric Operator Authentication
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#ef4444]" /> Multi-Model Sensei Rival Auditing
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#ef4444]" /> 9-Point Knowledge Telemetry &amp; Prompt-Cache Metrics
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#ef4444]" /> Cryptographic SHA-256 Hash-Chain Ledger (90-Day Archive)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-[#ef4444]" /> Perpetual Offline License (Zero Token Tax / BYOK)
                </li>
              </ul>
            </div>
            {/* Primary Buy CTA in Crimson */}
            <a
              href="https://jemakaib1.gumroad.com/l/sqwomh"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 w-full py-3 px-4 bg-[#ef4444] hover:bg-[#dc2626] text-white rounded-xl font-bold text-sm transition-colors shadow-lg shadow-[#ef4444]/25 flex items-center justify-center gap-2 text-center"
            >
              <Sparkles size={16} />
              Get Pro Lifetime ($199)
            </a>
          </div>
        </div>
      </section>

      {/* Enterprise Contact Modal */}
      <AnimatePresence>
        {contactModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0f172a] border border-white/10 rounded-2xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl"
            >
              <button
                onClick={() => setContactModalOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X size={20} />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-[#ef4444]/20 text-[#ef4444] flex items-center justify-center">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Enterprise &amp; Compliance Inquiry</h3>
                  <p className="text-xs text-slate-400 font-mono">Dedicated fleet deployments &amp; custom governance</p>
                </div>
              </div>

              <div className="space-y-4 text-sm text-slate-300">
                <p>
                  Order Samurai Compliance includes multi-project fleet telemetry, NIST AI RMF and EU AI Act evidence packs, and custom agent runtime hooks.
                </p>
                <div className="p-4 bg-slate-950 rounded-xl border border-white/5 space-y-2 text-xs font-mono">
                  <div className="text-slate-400">Direct Support &amp; Sales Channel:</div>
                  <div className="text-white font-bold select-all">support@ordersamurai.ai</div>
                </div>
                <a
                  href="mailto:support@ordersamurai.ai?subject=Order%20Samurai%20Enterprise%20Compliance%20Inquiry"
                  className="w-full py-3 bg-[#ef4444] hover:bg-[#dc2626] text-white rounded-xl font-bold text-sm shadow-lg shadow-[#ef4444]/25 transition-all flex items-center justify-center gap-2 text-center"
                >
                  Email Enterprise Sales
                </a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="border-t border-white/10 py-12 bg-[#05080c] text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-md bg-[#ef4444] flex items-center justify-center text-white">
              <IconTorii size={14} />
            </div>
            <span className="font-bold text-slate-300">Order Samurai</span>
            <span>© 2026 Order Samurai Contributors. Apache 2.0 License.</span>
          </div>

          <div className="flex gap-6 items-center flex-wrap">
            <a href="https://github.com/Gemkai/order-samurai/blob/main/TERMS.md" target="_blank" rel="noopener noreferrer" className="hover:text-slate-300">Terms &amp; EULA</a>
            <a href="https://github.com/Gemkai/order-samurai/blob/main/PRIVACY.md" target="_blank" rel="noopener noreferrer" className="hover:text-slate-300">Privacy Policy</a>
            <a href="https://github.com/Gemkai/order-samurai/blob/main/SECURITY.md" target="_blank" rel="noopener noreferrer" className="hover:text-slate-300">Security</a>
            <a href="mailto:support@ordersamurai.ai" className="hover:text-slate-300">Support (support@ordersamurai.ai)</a>
            <span className="text-slate-400 font-medium flex items-center gap-1">🛡️ 14-Day Money-Back Guarantee</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
