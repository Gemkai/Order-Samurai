#!/usr/bin/env python3
"""
Gumroad MCP Server & License Verification helper for Order Samurai.
Provides license key validation and activation via Gumroad's API (https://api.gumroad.com/v2/licenses/verify).
"""

import sys
import os
import json
import hashlib
import urllib.request
import urllib.parse
import urllib.error

GUMROAD_API_URL = "https://api.gumroad.com/v2/licenses/verify"
GUMROAD_PRODUCT_ID = os.environ.get("GUMROAD_PRODUCT_ID", "AePROIWPGu9a6k-dm9W4ww==")
GUMROAD_PERMALINK = os.environ.get("GUMROAD_PRODUCT_PERMALINK", "sqwomh")


# The seller disabled this key in Gumroad (Sales -> sale -> License key -> Disable).
# Gumroad answers HTTP 404 {"success": false, "message": "This license key has been
# disabled."}. That is an explicit revocation, distinct from an unknown key (not_found).
_DISABLED = {"valid": False, "disabled": True, "status": "disabled",
             "error": "license key has been disabled by the seller"}


def _says_disabled(err) -> bool:
    try:
        body = json.loads(err.read().decode("utf-8") or "{}")
    except Exception:
        return False
    return "disabled" in str(body.get("message", "")).lower()


def validate_license_key(license_key: str, product_id: str = None, increment_uses_count: bool = False, timeout: int = 15) -> dict:
    """Validate a Gumroad license key for Order Samurai Pro ($199)."""
    key = (license_key or "").strip()
    if not key:
        return {"valid": False, "error": "empty license key"}

    # No key-prefix bypass: every key is verified against Gumroad's API below.
    # Maintainer/CI Pro testing uses bin/make_dev_license.sh instead.
    pid = product_id or GUMROAD_PRODUCT_ID
    payload = {
        "product_id": pid,
        "license_key": key,
        "increment_uses_count": "true" if increment_uses_count else "false",
    }
    data = urllib.parse.urlencode(payload).encode("utf-8")
    req = urllib.request.Request(
        GUMROAD_API_URL,
        data=data,
        headers={"Accept": "application/json", "User-Agent": "OrderSamurai/1.0"}
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            res_data = json.loads(response.read().decode("utf-8"))
            success = res_data.get("success", False)
            purchase = res_data.get("purchase") or {}
            # A dispute the seller won leaves the purchase in good standing.
            refunded = bool(purchase.get("refunded") or purchase.get("chargebacked")
                            or (purchase.get("disputed") and not purchase.get("dispute_won")))
            if not success:
                if "disabled" in str(res_data.get("message", "")).lower():
                    return dict(_DISABLED)
                return {"valid": False, "not_found": True, "error": "license key not recognized by Gumroad"}
            return {
                "valid": success and not refunded,
                "license_key": key,
                "customer_email": purchase.get("email"),
                "status": "refunded" if refunded else ("active" if success else "invalid"),
                "refunded": refunded,
                "uses": res_data.get("uses", 1),
                # Start of the refund window that licensing.revalidate() enforces.
                "purchased_at": purchase.get("sale_timestamp") or purchase.get("created_at"),
            }
    except urllib.error.HTTPError as err:
        if err.code == 404:
            if _says_disabled(err):
                return dict(_DISABLED)
            return {"valid": False, "not_found": True, "error": "license key not recognized by Gumroad"}
        if err.code >= 500:
            return {"valid": False, "error": f"Could not reach Gumroad (HTTP {err.code}). Try again shortly."}
        return {"valid": False, "error": f"Gumroad API HTTP {err.code}"}
    except urllib.error.URLError as err:
        return {"valid": False, "error": f"Could not reach Gumroad ({err.reason}). Check your network connection and try again."}
    except (TimeoutError, OSError) as err:
        return {"valid": False, "error": f"Could not reach Gumroad ({err}). Check your network connection and try again."}
    except Exception as e:
        return {"valid": False, "error": str(e)}


def activate_license_key(license_key: str, instance_name: str) -> dict:
    """Activate a Gumroad license key for a local developer machine."""
    val = validate_license_key(license_key, increment_uses_count=True)
    if not val.get("valid"):
        return {"activated": False, "error": val.get("error", "invalid key")}

    instance_hash = hashlib.sha256(f"{license_key}:{instance_name}".encode("utf-8")).hexdigest()[:16]
    return {
        "activated": True,
        "instance_id": f"gum_{instance_hash}",
        "instance_name": instance_name,
        "license_key": license_key,
        "customer_email": val.get("customer_email"),
        "simulated": bool(val.get("simulated")),
    }


def create_checkout_link() -> dict:
    """Return the official Gumroad product link for Order Samurai Pro ($199)."""
    url = os.environ.get("GUMROAD_PRODUCT_URL", "https://jemakaib1.gumroad.com/l/sqwomh")
    return {
        "url": url,
        "amount": 199.00,
        "currency": "USD",
        "tier": "Pro Lifetime",
        "provider": "Gumroad",
    }


def main():
    """Stdio MCP server loop implementing Model Context Protocol for Gumroad."""
    tools = [
        {
            "name": "gumroad_validate_license",
            "description": "Validates an Order Samurai Pro $199 lifetime license key via Gumroad.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "license_key": {"type": "string", "description": "Gumroad license key string"},
                    "product_permalink": {"type": "string", "description": "Optional product permalink"}
                },
                "required": ["license_key"]
            }
        },
        {
            "name": "gumroad_activate_license",
            "description": "Activates a Gumroad license key for a developer machine instance.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "license_key": {"type": "string", "description": "Gumroad license key string"},
                    "instance_name": {"type": "string", "description": "Developer machine name or hostname"}
                },
                "required": ["license_key", "instance_name"]
            }
        }
    ]

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            method = req.get("method")
            msg_id = req.get("id")

            if method == "initialize":
                resp = {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "ordersamurai-gumroad-mcp", "version": "1.0.0"}
                    }
                }
            elif method == "tools/list":
                resp = {"jsonrpc": "2.0", "id": msg_id, "result": {"tools": tools}}
            elif method == "tools/call":
                params = req.get("params", {})
                tool_name = params.get("name")
                args = params.get("arguments", {})

                if tool_name == "gumroad_validate_license":
                    res = validate_license_key(args.get("license_key"), args.get("product_permalink"))
                elif tool_name == "gumroad_activate_license":
                    res = activate_license_key(args.get("license_key"), args.get("instance_name"))
                else:
                    res = {"error": f"Unknown tool: {tool_name}"}

                resp = {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": {
                        "content": [{"type": "text", "text": json.dumps(res, indent=2)}]
                    }
                }
            else:
                resp = {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32601, "message": "Method not found"}}

            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
        except Exception as err:
            err_resp = {"jsonrpc": "2.0", "id": None, "error": {"code": -32603, "message": str(err)}}
            sys.stdout.write(json.dumps(err_resp) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
